#!/usr/bin/env python3
"""Validate complete benchmark collections and write a compact, reproducible results package."""
import argparse
import gzip
import hashlib
import io
import json
import math
import pathlib
import statistics
import tarfile
import types

import run as collection_runner
import build as collection_build

PHASES = ('prepare-essential', 'receive-essential', 'artifacts', 'certificate', 'disk', 'disk-withdrawals')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def read_json(path):
    return json.loads(path.read_bytes())


def key(task):
    return json.dumps(task, sort_keys=True, separators=(',', ':'))


def frozen_harness(path):
    """Load only the hash-checked runner used to define the frozen collection inventory."""
    with tarfile.open(path) as archive:
        files = {}
        members = archive.getmembers()
        require(len(members) <= 256, 'oversized harness inventory')
        for member in members:
            require(member.size <= 8 * 1024 * 1024, 'oversized harness member')
            name = pathlib.PurePosixPath(member.name)
            require(member.isfile() and not name.is_absolute() and '..' not in name.parts, 'unsafe harness member')
            require(member.name not in files, 'duplicate harness member')
            require(not set(name.parts) & {'aws', 'bin', 'results', '__pycache__'}, 'forbidden harness member')
            files[member.name] = archive.extractfile(member).read()
    hashes = json.loads(files['SHA256.json'])
    require(set(files) == set(hashes) | {'SHA256.json'}, 'harness inventory mismatch')
    require(all(digest(files[p]) == h for p, h in hashes.items()), 'harness hash mismatch')
    if 'RUNNER-CHANGE.json' in files:
        change = json.loads(files['RUNNER-CHANGE.json'])
        require(change['changed_existing_files'] == ['run.py'] and change['runner_sha256'] == digest(files['run.py']) and change['patch_sha256'] == digest(files['runner-only.patch']), 'runner correction provenance mismatch')
    require(files['run.py'] == pathlib.Path(collection_runner.__file__).read_bytes(), 'packager runner differs from measured harness')
    require(files['build.py'] == pathlib.Path(collection_build.__file__).read_bytes(), 'packager builder differs from measured harness')
    return files, collection_runner


def expected_tasks(runner, phase):
    return runner.plan(types.SimpleNamespace(phase=phase, profile=None, variant=None, mode=None))


def valid_hash(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def check_source(source, variant, files, diagnostic):
    pins = {'qmdb': 'b93fed3ae2ad75d2ceafa9db7545b381d1e875c4', 'reference': '3a3b934662d1d590ea553b8734d241041b6b8182'}
    require(source['variant'] == variant and source['source_revision'] == pins[variant], 'unexpected source revision')
    require(valid_hash(source['binary_sha256']) and valid_hash(source['lock_sha256']), 'missing binary/lock hashes')
    require(source['source_sha256'] and all(valid_hash(v) for v in source['source_sha256'].values()), 'missing native source hashes')
    require(source['overlay_sha256'] and all(valid_hash(v) for v in source['overlay_sha256'].values()), 'missing overlay hashes')
    require(source['source_sha256']['Cargo.lock'] == source['lock_sha256'], 'lock identity mismatch')
    require(source['environment']['RUSTFLAGS'] == '--cfg full_bench', 'unexpected compiler flags')
    if diagnostic:
        return
    overlay = source['overlay_sha256']
    native = 'candidate' if variant == 'qmdb' else 'reference'
    required = {f'latency_{native}.rs': f'{native}/latency_{native}.rs'}
    for name in files:
        if name.startswith('artifacts/common/') and name.endswith('.rs'):
            required[name.removeprefix('artifacts/common/')] = name
        elif name.startswith(f'artifacts/{native}/') and name.endswith('.rs'):
            required['artifact_latency/' + pathlib.PurePosixPath(name).name] = name
    if variant == 'qmdb':
        required.update({name: 'candidate/' + name for name in ('latency_disk.rs', 'disk_fixture.rs')})
        patch = source.get('source_patch', {})
        require(patch.get('sha256') == digest(files['final-candidate.patch']), 'candidate patch identity mismatch')
        require(patch.get('base_revision') == pins[variant] and patch.get('application_checked') == 'git apply --reverse --check', 'candidate patch binding missing')
    main = collection_build.MAIN.replace('LATENCY_MODULE', 'latency_' + native).replace('VARIANT_VALUE', variant)
    if variant == 'qmdb':
        main = main.replace('mod latency_candidate;', 'mod latency_candidate;\nmod latency_disk;\nmod disk_fixture;')
        main = main.replace('else {latency_candidate::run(&mode,samples,warmup);}', 'else if mode.starts_with("disk-receive-") {latency_disk::run(&mode,samples,warmup);} else {latency_candidate::run(&mode,samples,warmup);}')
    require(overlay.get('bench.rs') == digest(main.encode()), 'generated benchmark entrypoint differs')
    require(all(overlay.get(name) == digest(files[path]) for name, path in required.items()), 'measured adapter differs from reproduction source')


def finite_samples(values):
    return bool(values) and all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v > 0 for v in values)


def summary(values):
    result = {'samples': len(values), 'median_ns': statistics.median(values), 'min_ns': min(values), 'max_ns': max(values)}
    if len(values) > 1:
        q = statistics.quantiles(values, n=4, method='inclusive')
        result.update(q1_ns=q[0], q3_ns=q[2])
    return result


def validate_phase(directory, runner, files, diagnostic=False):
    manifest = read_json(directory / 'manifest.json')
    phase = manifest['phase']
    require(phase == 'preflight' if diagnostic else phase in PHASES, 'unexpected phase')
    wanted = expected_tasks(runner, phase)
    require(sorted(map(key, manifest['plan'])) == sorted(map(key, wanted)), 'manifest plan inventory mismatch')
    for variant, source in manifest['sources'].items():
        check_source(source, variant, files, diagnostic)
    require(set(manifest['sources']) == {t['variant'] for t in wanted}, 'source variant inventory mismatch')
    run_paths = sorted(directory.glob('*/run.json'))
    require(len(run_paths) == len(wanted), 'process inventory incomplete')
    require(read_json(directory / 'complete.json')['runs'] == len(wanted), 'phase incomplete')
    observed, normalized, raw, evidence, oracles = [], [], [], {}, {}
    for path in run_paths:
        r = read_json(path)
        t = r['task']; mode = t['mode']; variant = t['variant']; p = t['profile']
        identity = phase + '/' + path.parent.name
        observed.append(key(t))
        require(r['validation'] == 'passed' and r['exit_code'] == 0 and r['stop_reason'] is None, 'unsuccessful process')
        records = read_json(path.with_name('records.json'))
        require(records == runner.json_records(path.with_name('stdout.log')), 'raw JSONL differs from records')
        require(r['artifact_sizes'] == runner.artifact_size_records(path.with_name('stderr.log')), 'encoded size records differ')
        metadata = [x for x in records if x.get('record') == 'metadata']
        require(len(metadata) == 1 and sum(x.get('record') == 'complete' for x in records) == 1, 'missing metadata/completion')
        m = metadata[0]
        require(all(m[k] == p[k] for k in ('N', 'A', 'R', 'K')) and m['mode'] == mode and m['variant'] == variant, 'process identity mismatch')
        require(m['workers'] == 16 and m['validators'] == 100, 'worker/committee mismatch')
        samples = 1 if diagnostic else r['samples']; warmup = 0 if diagnostic else r['warmup']
        require(samples >= (1 if diagnostic else 10) and warmup >= 0, 'insufficient samples')
        if not diagnostic:
            require(samples == manifest['settings']['samples'] and warmup == manifest['settings']['warmup'], 'run differs from phase sample/warmup plan')
        require(m['samples'] == samples and m['warmup'] == warmup, 'sample configuration mismatch')
        base = {'run': identity, 'phase': phase, 'diagnostic': diagnostic, 'variant': variant, 'profile': p, 'mode': mode,
                'binary_sha256': manifest['sources'][variant]['binary_sha256']}
        raw.append({'kind': 'process', **base, 'run_record': r})
        raw.extend({'kind': 'record', 'run': identity, 'value': value} for value in records)
        if mode != 'artifact-latency':
            sequence = [x for x in records if x.get('record') == 'sample']
            require(len(sequence) == samples + warmup, 'sample inventory mismatch')
            for step, sample in enumerate(sequence):
                epoch = 7 if mode.startswith('seal') or mode in ('balance-fetch', 'sign-vote') else 7 + step
                require(sample['sample'] == step and sample['epoch'] == epoch and sample['warmup'] == (step < warmup), 'sample lifetime mismatch')
                require(sample['variant'] == variant and sample['mode'] == mode, 'sample identity mismatch')
            values = [x['nanoseconds'] for x in sequence if not x['warmup']]
            require(finite_samples(values) and values == r['timing_ns']['samples'], 'invalid/raw timing mismatch')
            normalized.append(base | {'operation': mode, **summary(values)})
            phases = [x for x in records if x.get('record') == 'phase']
            names = ({'decode', 'resident-hydrate', 'verify-and-vote', 'apply'} if variant == 'reference' else {'decode', 'validate-decoded', 'vote', 'verify-and-vote', 'apply'}) if mode == 'receive-phases' else ({'decode', 'validate-decoded', 'vote', 'apply', 'commit'} if mode.startswith('disk-') else set())
            require(len(phases) == len(names) * len(sequence), 'phase inventory mismatch')
            for step, total in enumerate(sequence):
                parts = [x for x in phases if x['sample'] == step]
                require({x['phase'] for x in parts} == names and len(parts) == len(names), 'duplicate/missing phase')
                require(all(x['epoch'] == total['epoch'] and x['warmup'] == total['warmup'] and x['mode'] == mode and x['variant'] == variant and 0 <= x['nanoseconds'] <= total['nanoseconds'] for x in parts), 'phase scope/identity mismatch')
                durations = {x['phase']: x['nanoseconds'] for x in parts}
                nested = mode == 'receive-phases' and variant == 'qmdb'
                if nested:
                    require(durations['validate-decoded'] + durations['vote'] <= durations['verify-and-vote'], 'nested validation/vote exceeds enclosing scope')
                exclusive = [v for k, v in durations.items() if not (nested and k in ('validate-decoded', 'vote'))]
                require(sum(exclusive) <= total['nanoseconds'], 'adjacent phases exceed outer scope')
            for name in sorted(names):
                values = [x['nanoseconds'] for x in phases if x['phase'] == name and not x['warmup']]
                require(values == r['phase_timings_ns'][name], 'stored phase summary differs from raw')
                normalized.append(base | {'operation': mode + '::' + name, 'nested_scope': mode == 'receive-phases' and variant == 'qmdb' and name in ('validate-decoded', 'vote'), **summary(values)})
            state = runner.oracle(records)
            require(state['epochs'] == samples + warmup and valid_hash(state['fingerprint']), 'invalid logical oracle')
            require(state == r['oracle'], 'stored oracle differs from raw')
            oracles[(p['id'], mode, variant)] = state
            if mode.startswith('disk-'):
                checked = runner.validate_disk_records(records, t, samples, warmup)
                require(checked['disk_metadata'] == r['disk_metadata'] and checked['disk_metrics'] == r['disk_metrics'], 'disk summary differs from raw')
                for row in normalized:
                    if row['run'] == identity:
                        row.update(storage=checked['disk_metadata'], counter_scope=checked['counter_scope'])
        elif not diagnostic:
            require('--bench' in r['command'] and '--test' not in r['command'], 'timed Criterion command must use --bench')
            cases = []
            for sample_path in sorted(path.parent.glob('criterion/**/new/sample.json')):
                sample = read_json(sample_path); label = read_json(sample_path.with_name('benchmark.json'))
                estimates = read_json(sample_path.with_name('estimates.json'))
                require(len(sample['iters']) >= samples and len(sample['iters']) == len(sample['times']) and finite_samples(sample['iters']) and finite_samples(sample['times']), 'invalid Criterion samples')
                case = runner.artifact_case(label['full_id']); cases.append(case)
                operation, labels = case; labels = dict(labels)
                sizes = [x for x in r['artifact_sizes'] if x['artifact'] == operation.split('::')[0] and all(x.get(k) == v for k, v in labels.items())]
                require(len(sizes) == 1, 'missing/ambiguous encoded byte join')
                require(isinstance(sizes[0]['bytes'], int) and sizes[0]['bytes'] >= 0, 'invalid encoded byte size')
                values = [ns / count for ns, count in zip(sample['times'], sample['iters'])]
                normalized.append(base | {'operation': label['full_id'], 'encoded_bytes': sizes[0]['bytes'], 'size_context': sizes[0], **summary(values)})
                raw.append({'kind': 'criterion', 'run': identity, 'benchmark': label, 'sample': sample, 'estimates': estimates, 'size_context': sizes[0]})
                for f in (sample_path, sample_path.with_name('benchmark.json'), sample_path.with_name('estimates.json')):
                    evidence[str(f.relative_to(directory))] = digest(f.read_bytes())
            require(len(cases) == len(set(cases)) and set(cases) == runner.expected_artifact_cases(t), 'Criterion case inventory incomplete/duplicate')
            require(r['criterion_cases'] == len(cases), 'Criterion summary count mismatch')
        for name in ('run.json', 'records.json', 'stdout.log', 'stderr.log'):
            f = path.with_name(name); evidence[str(f.relative_to(directory))] = digest(f.read_bytes())
    require(sorted(observed) == sorted(map(key, wanted)), 'missing/duplicate/unexpected task')
    if phase in ('prepare-essential', 'receive-essential', 'preflight'):
        for (profile, mode, variant), value in oracles.items():
            require(oracles.get((profile, mode, 'reference' if variant == 'qmdb' else 'qmdb')) == value, 'paired logical oracle mismatch')
    if phase in ('disk', 'disk-withdrawals'):
        for (profile, mode, variant), value in oracles.items():
            other = 'disk-receive-first-touch' if mode == 'disk-receive-steady' else 'disk-receive-steady'
            require(oracles.get((profile, other, variant)) == value, 'disk condition oracle mismatch')
    for name in ('manifest.json', 'complete.json', 'results.json'):
        evidence[name] = digest((directory / name).read_bytes())
    return {'manifest': manifest, 'input_sha256': evidence, 'rows': normalized, 'raw': raw, 'oracles': oracles}


def reproduction(files):
    kept = {p: b for p, b in files.items() if p.endswith(('.rs', '.py')) or p in ('final-candidate.patch', 'runner-only.patch', 'RUNNER-CHANGE.json')}
    kept['package_results.py'] = pathlib.Path(__file__).read_bytes()
    kept['SHA256.json'] = encoded({p: digest(b) for p, b in sorted(kept.items())})
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, data in sorted(kept.items()):
                member = tarfile.TarInfo(name); member.size = len(data); member.mode = 0o644
                archive.addfile(member, io.BytesIO(data))
    return stream.getvalue()


def readme(rows, collection):
    sources = collection['sources']
    host = collection['designation']
    cpu = ', '.join(collection['cpu_models'])
    compiler = sources['qmdb']['rustc'].splitlines()[0]
    reference = sources['reference']['source_revision'][:12]
    candidate = sources['qmdb']['source_revision'][:12]
    lines = ['# Bajillion benchmark results', '',
             f'Host: `{host}` ({cpu}); toolchain: `{compiler}`. Reference: `{reference}`. QMDB: `{candidate}` plus `final-candidate.patch`. Full source, patch and binary hashes are in manifest.json.', '',
             'N is the number of live accounts, A the number of senders, R the recipient pool size, and K the recipients per sender. W counts signed withdrawals in the disk sensitivity runs.', '',
             'The tables report direct sample medians. Paired memory runs use 16 Rayon workers and 100 validators on this host. Workload keys, opening balances and transfer graph match; native validation contracts differ. Raw samples, warmups, logical oracles, Criterion iterations/times/estimates and byte joins are retained in samples.jsonl.gz.', '',
             'Prepare/apply starts from signed terminal inputs and includes reference transpose/row/prefix derivation, native preparation and encoding, and reusable successor state; sender signature material and maintained reference checksum partials are outside timing.', '',
             'Receive means encoded bytes through validation, vote and applied state for one validator: the reference selects and fixes the validator with the largest encoded dealing, while every QMDB validator receives the same packet. These are individual receiver timings, not mean validator latency or aggregate committee work. Memory runs exclude durability. Candidate validation includes native balance reads and root preparation; reference resident expansion is separate. Candidate validation and vote are nested within verify-and-vote: do not add overlapping rows or infer components by subtraction.', '',
             'Filesystem rows additionally include native QMDB commit, excluding accepted-close/evidence journals, SQL, network and publication. They use aligned 4096-byte physical pages and a 4 MiB native cache. First-touch clears the actual native page cache after reopen; OS cache and native tails remain uncontrolled. Whole-receive Blob requested reads are not device reads or per-phase I/O costs.', '',
             'The initial one-sample preflight is diagnostic only and is excluded from these tables.', '',
             '| N | A | R | K | Operation | Reference ms | QMDB ms |', '|---:|---:|---:|---:|---|---:|---:|']
    paired = {}
    for r in rows:
        if r['diagnostic'] or r['mode'].startswith('disk-') or r['mode'] == 'artifact-latency' or '::' in r['operation']:
            continue
        p = r['profile']; identity = tuple(p[k] for k in ('N', 'A', 'R', 'K')) + (r['operation'],)
        paired.setdefault(identity, {})[r['variant']] = r['median_ns'] / 1e6
    for identity, values in sorted(paired.items()):
        lines.append('| ' + ' | '.join(map(str, identity)) + f" | {values.get('reference', float('nan')):.6f} | {values.get('qmdb', float('nan')):.6f} |")
    lines += ['', '| Candidate N | A | R | K | Decode ms | Validate ms | Vote ms | Apply ms | Receive ms |', '|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    candidate = {}
    for row in rows:
        if not row['diagnostic'] and row['variant'] == 'qmdb' and row['mode'] == 'receive-phases':
            profile = tuple(row['profile'][k] for k in ('N', 'A', 'R', 'K'))
            candidate.setdefault(profile, {})[row['operation']] = row['median_ns'] / 1e6
    for profile, values in sorted(candidate.items()):
        columns = ['receive-phases::' + name for name in ('decode', 'validate-decoded', 'vote', 'apply')] + ['receive-phases']
        lines.append('| ' + ' | '.join(map(str, profile)) + ' | ' + ' | '.join(f'{values[name]:.6f}' for name in columns) + ' |')
    lines += ['', 'Phase medians are summarized independently and need not add to the total median. The nested verify-and-vote row remains in results.json.', '', '| Disk N | A | W | Condition | Receive through QMDB commit ms | Commit ms |', '|---:|---:|---:|---|---:|---:|']
    disk = {}
    for row in rows:
        if not row['diagnostic'] and row['mode'].startswith('disk-'):
            identity = (row['profile']['N'], row['profile']['A'], row['storage']['W'], row['mode'])
            disk.setdefault(identity, {})[row['operation']] = row['median_ns'] / 1e6
    for identity, values in sorted(disk.items()):
        mode = identity[-1]
        lines.append('| ' + ' | '.join(map(str, identity)) + f' | {values[mode]:.6f} | {values[mode + "::commit"]:.6f} |')
    lines += ['', 'Full phase, artifact and disk medians with exact operation labels and encoded bytes are in results.json. Source and binary identities are in manifest.json.', '',
              '## Reproduce', '',
              'Extract reproduction.tar.gz. Obtain disposable exports of the pinned commits recorded in manifest.json, verify their archive hashes, and apply final-candidate.patch to the candidate. With the recorded Rust toolchain, run:', '',
              '```sh', 'python3 build.py --reference ../reference --candidate ../qmdb --candidate-patch final-candidate.patch --jobs 8',
              'python3 run.py --phase receive-essential --output results/receive-essential --external-host YOUR_QUIET_HOST --execute',
              '```', '',
              'Repeat the recorded phases prepare-essential, artifacts and certificate. For disk and disk-withdrawals, also pass --disk-root with a fresh real-filesystem directory. Stop builds before timing. Each phase manifest retains the exact arguments and complete task inventory. The reproduction archive contains measured custom Rust/Python sources and the candidate patch; native exports and binaries are identified by hash rather than duplicated here. The diagnostic preflight used earlier binaries, whose identities remain separate. RUNNER-CHANGE.json and runner-only.patch preserve the original harness identity and the direct Criterion --bench invocation correction; completed preparation/receive binaries and data are unchanged.', '']
    return '\n'.join(lines).encode()


def package(args):
    files, runner = frozen_harness(args.harness)
    archives = {}
    for item in getattr(args, 'source_archive', []) or []:
        variant, filename = item.split('=', 1)
        require(variant in ('reference', 'qmdb') and variant not in archives, 'duplicate/unknown source archive')
        path = pathlib.Path(filename)
        native = {}
        with tarfile.open(path) as archive:
            for name in ('fixtures.rs', 'admission_fixtures.rs'):
                member = archive.getmember('clearing/src/bajillion/benches/' + name)
                require(member.isfile() and member.size <= 8 * 1024 * 1024, 'invalid native fixture member')
                native[name] = archive.extractfile(member).read()
        archives[variant] = {'path': str(path), 'sha256': digest(path.read_bytes()), 'fixture_bytes': native}
    require(set(archives) == {'reference', 'qmdb'}, 'provide both --source-archive reference=PATH and qmdb=PATH')
    phases = [validate_phase(p, runner, files) for p in args.phases]
    require(sorted(x['manifest']['phase'] for x in phases) == sorted(PHASES), 'all six final collection phases are required exactly once')
    diagnostic = validate_phase(args.preflight, runner, files, diagnostic=True)
    # A comparison needs the same physical host/toolchain and a stable measured binary per variant.
    signatures = {(x['manifest']['hostname'], x['manifest']['platform'], tuple(x['manifest']['cpu_models'])) for x in phases}
    require(len(signatures) == 1, 'mixed final benchmark hosts')
    compilers = {s['rustc'] for x in phases for s in x['manifest']['sources'].values()}
    require(len(compilers) == 1, 'mixed final compiler toolchains')
    for variant in ('reference', 'qmdb'):
        sources = [x['manifest']['sources'][variant] for x in phases if variant in x['manifest']['sources']]
        identity_fields = ('binary_sha256', 'source_revision', 'source_sha256', 'overlay_sha256', 'lock_sha256', 'rustc', 'command', 'environment', 'source_patch', 'source_archive')
        require(len({json.dumps({k: s.get(k) for k in identity_fields}, sort_keys=True) for s in sources}) == 1, 'conflicting final build identities for variant')
        source = sources[0]; archive = archives[variant]
        if source.get('source_archive'):
            require(source['source_archive']['sha256'] == archive['sha256'] and source['source_archive']['revision'] == source['source_revision'], 'source archive identity mismatch')
        native = archive['fixture_bytes']
        for name, data in native.items():
            require(source['source_sha256'].get('clearing/src/bajillion/benches/' + name) == digest(data), 'native fixture differs from source export')
        fixture = native['fixtures.rs'].decode()
        needle = 'pub(crate) fn selected_active_profiles() -> Vec<(usize, ActiveProfile)> {'
        require(fixture.count(needle) == 1, 'native profile entrypoint missing')
        fixture = fixture.replace(needle, needle + '\n    if std::env::var_os("COMMONWARE_LATENCY_N").is_some() { return vec![(0,latency_profile())]; }', 1) + collection_build.PROFILE
        require(source['overlay_sha256']['fixtures.rs'] == digest(fixture.encode()), 'modified fixture differs from frozen builder')
        require(source['overlay_sha256']['admission_fixtures.rs'] == digest(native['admission_fixtures.rs']), 'committee fixture differs from source export')
    by_phase = {x['manifest']['phase']: x for x in phases}
    for (profile, mode, variant), state in by_phase['prepare-essential']['oracles'].items():
        received = by_phase['receive-essential']['oracles'][(profile, 'receive-phases', variant)]
        if state['epochs'] == received['epochs']:
            require(state == received, 'prepare/receive logical oracle mismatch')
    require(len({(x['manifest']['settings']['samples'], x['manifest']['settings']['warmup']) for x in phases if x['manifest']['phase'] in ('prepare-essential', 'receive-essential', 'disk', 'disk-withdrawals')}) == 1, 'different measured epoch ranges across raw collections')
    rows = [r for phase in phases + [diagnostic] for r in phase['rows']]
    raw = [r for phase in phases + [diagnostic] for r in phase['raw']]
    repro = reproduction(files)
    payload = io.BytesIO()
    with gzip.GzipFile(fileobj=payload, mode='wb', mtime=0, filename='') as stream:
        for row in raw:
            stream.write(encoded(row))
    outputs = {'README.md': readme(rows, by_phase['prepare-essential']['manifest']), 'results.json': encoded(rows), 'samples.jsonl.gz': payload.getvalue(), 'reproduction.tar.gz': repro}
    manifests = {x['manifest']['phase']: {'collection': x['manifest'], 'input_sha256': x['input_sha256'], 'diagnostic': x is diagnostic} for x in phases + [diagnostic]}
    manifest = {'schema': 1, 'runner_change': json.loads(files['RUNNER-CHANGE.json']) if 'RUNNER-CHANGE.json' in files else None, 'source_archives': {variant: {k: a[k] for k in ('path', 'sha256')} for variant, a in archives.items()}, 'harness_archive_sha256': digest(args.harness.read_bytes()), 'harness_file_sha256': json.loads(files['SHA256.json']), 'collections': manifests,
                'output_sha256': {p: digest(b) for p, b in outputs.items()}, 'packager_sha256': digest(pathlib.Path(__file__).read_bytes())}
    outputs['manifest.json'] = encoded(manifest)
    if args.validate_only:
        return {'validated': True, 'collections': len(manifests), 'rows': len(rows), 'raw_records': len(raw)}
    require(not args.output.exists(), 'output already exists')
    args.output.mkdir(parents=True)
    for name, data in outputs.items():
        (args.output / name).write_bytes(data)
    return {'output': str(args.output), 'files': list(outputs), 'rows': len(rows), 'raw_records': len(raw)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phases', type=pathlib.Path, nargs='+')
    parser.add_argument('--preflight', type=pathlib.Path, required=True)
    parser.add_argument('--harness', type=pathlib.Path, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    parser.add_argument('--source-archive', action='append', default=[], metavar='VARIANT=PATH', help='Verified original git-archive export; provide reference and qmdb')
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    try:
        print(json.dumps(package(args), indent=2))
    except (ValueError, KeyError, AssertionError, OSError) as error:
        parser.exit(1, f'Invalid benchmark collection: {error}\n')


if __name__ == '__main__':
    main()
