#!/usr/bin/env python3
"""Plan or run serial matched benchmarks on a designated external Linux host."""
import argparse, hashlib, json, os, pathlib, platform, statistics, subprocess, time
ROOT = pathlib.Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def profiles():
    result = []
    for n, a in [(1024,1024),(10000,10000),(100000,100000),(1000000,1000000),(1000000,1024),(1000000,10000),(1000000,100000)]:
        for k in (1,8):
            result.append({'id': f'n{n}-a{a}-r512-k{k}', 'N':n,'A':a,'R':512,'K':k})
    return result

def task(profile, variant, mode, group=None, smoke=False):
    return {'profile':profile,'variant':variant,'mode':mode,'group':group,'smoke':smoke}

def plan(args):
    ps = profiles()
    tasks = []
    if args.phase == 'preflight':
        p = ps[7]
        for mode in ('prepare-apply','receive-apply'):
            tasks += [task(p,v,mode) for v in ('reference','qmdb')]
        tasks += [task(p,v,'artifact-latency','all',True) for v in ('reference','qmdb')]
    elif args.phase in ('close','close-profiled'):
        for index,p in enumerate(ps):
            for mode in ('prepare-apply','receive-phases' if args.phase=='close-profiled' else 'receive-apply'):
                order = ('reference','qmdb') if index % 2 == 0 else ('qmdb','reference')
                tasks += [task(p,v,mode) for v in order]
    elif args.phase == 'prepare':
        for index,p in enumerate(ps):
            tasks += [task(p,v,'prepare-apply') for v in (('reference','qmdb') if index%2==0 else ('qmdb','reference'))]
    elif args.phase in ('prepare-essential','receive-essential'):
        essential=[ps[0],ps[2],ps[4],ps[6],ps[8],ps[1],ps[9],{'id':'n1000000-a1024-r8-k8','N':1000000,'A':1024,'R':8,'K':8}]
        for index,p in enumerate(essential):
            tasks += [task(p,v,'prepare-apply' if args.phase=='prepare-essential' else 'receive-phases') for v in (('reference','qmdb') if index%2==0 else ('qmdb','reference'))]
    elif args.phase == 'phases':
        for p in [ps[0],ps[1],ps[8],ps[9]]:
            tasks += [task(p,v,'receive-phases') for v in ('reference','qmdb')]
    elif args.phase == 'seal-matched':
        for p in [ps[0],ps[1],ps[8],ps[9]]:
            tasks += [task(p,v,'seal-predecoded') for v in ('reference','qmdb')]
    elif args.phase == 'balance-fetch':
        tasks += [task(p,'qmdb','balance-fetch') for p in ps[::2]]
    elif args.phase in ('disk','disk-withdrawals'):
        disk_profiles=[ps[2],ps[8]] if args.phase=='disk' else [{'id':'n64-a64-r8-k1-w4','N':64,'A':64,'R':8,'K':1}]
        for profile in disk_profiles:
            for mode in ('disk-receive-steady','disk-receive-first-touch'):
                tasks.append(task(profile,'qmdb',mode)|{'withdrawals':4 if args.phase=='disk-withdrawals' else 0})
    elif args.phase == 'artifacts':
        for p in ps[:8:2]:
            tasks += [task(p,v,'artifact-latency','all') for v in ('reference','qmdb')]
        # Vector degree and sender concentration can change challenge/receipt paths.
        for p in [ps[1], ps[9]]:
            for group in ('challenge','acceptance'):
                tasks += [task(p,v,'artifact-latency',group) for v in ('reference','qmdb')]
    elif args.phase == 'certificate':
        tasks += [task(ps[0],v,'artifact-latency','certificate') for v in ('reference','qmdb')]
    elif args.phase == 'seal':
        for p in [ps[0],ps[1],ps[8],ps[9]]:
            tasks += [task(p,'reference','seal-predecoded'),task(p,'qmdb','seal-decode')]
        tasks.append(task(ps[0],'qmdb','sign-vote'))
    elif args.phase == 'concentrated':
        for k in (1,8):
            p = {'id':f'n1000000-a1024-r8-k{k}','N':1000000,'A':1024,'R':8,'K':k}
            for mode in ('prepare-apply','receive-apply'):
                tasks += [task(p,v,mode) for v in ('reference','qmdb')]
            for group in ('challenge','acceptance'):
                tasks += [task(p,v,'artifact-latency',group) for v in ('reference','qmdb')]
    if args.profile:
        tasks = [t for t in tasks if t['profile']['id'] in args.profile]
    if args.variant:
        tasks = [t for t in tasks if t['variant'] in args.variant]
    if args.mode:
        tasks = [t for t in tasks if t['mode'] in args.mode]
    return tasks

def artifact_size_records(path):
    values=[]
    for line in path.read_text(errors='replace').splitlines():
        if line.startswith('artifact bytes: '):
            fields=dict(item.split('=',1) for item in line[len('artifact bytes: '):].split() if '=' in item)
            if 'bytes' in fields:
                fields['bytes']=int(fields['bytes']);values.append(fields)
    return values

def json_records(path):
    records = []
    for line in path.read_text(errors='replace').splitlines():
        if line.startswith('{'):
            try: records.append(json.loads(line))
            except json.JSONDecodeError: pass
    return records

def expected_artifact_cases(t):
    p=t['profile'];selected=t['group'];variant=t['variant']
    if selected=='certificate':
        labels={'n':'100','f':'33','q':'67','contract':'close_amounts' if variant=='qmdb' else 'terminal_proof'}
        return {('native_certified::verify_certified_commitment',tuple(sorted(labels.items())))}
    cases=set()
    common={str(k):str(p[k]) for k in ('N','A','R','K')}|{'validators':'100','workers':'16'}
    def add(group, operation, **labels):
        cases.add((group+'::'+operation,tuple(sorted((common|labels).items()))))
    if selected in ('all','challenge'):
        for op in ('verify','receive'):
            for kind in ('debit','entry','fork'):add('challenge',op,kind=kind)
    if selected in ('all','acceptance'):
        for op in ('verify','receive'):
            for kind in ('receipt','ack','authorization'):add('acceptance',op,kind=kind)
    if selected in ('all','withdrawal'):
        for w in sorted({v for v in (1,8,64,512,1024,10000,100000,1000000,p['N']) if v<=p['N']}):
            for op in ('verify','receive'):
                for action in ('amount','close'):add('withdrawal',op,W=str(w),action=action,fixture='standalone_output_tree')
    if selected in ('all','state'):
        contexts=['predecessor','successor_after_apply','historical_predecessor_after_apply' if variant=='qmdb' else 'retained_predecessor_after_apply']
        for context in contexts:
            for op in ('verify','receive'):
                for kind in ('opening','present','absent'):add('state',op,context=context,kind=kind,contract='current_mmb' if variant=='qmdb' else 'state_cache_bmt')
    return cases

def artifact_case(full_id):
    operation,labels=full_id.split('::artifact_latency::',1)[1].split('/',1)
    return operation,tuple(sorted(tuple(item.split('=',1)) for item in labels.split()))

def snapshot():
    result = {'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'load':os.getloadavg()}
    if pathlib.Path('/proc/meminfo').exists():
        result['memory'] = {line.split(':')[0]:line.split(':')[1].strip() for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemTotal:','MemAvailable:','SwapTotal:','SwapFree:'))}
    return result

def oracle(records):
    values = [r for r in records if r.get('record')=='oracle']
    assert len(values)==1, 'exactly one completed state oracle required'
    value = values[0]
    return {'epochs':value.get('completed_epochs',value.get('epochs')), 'fingerprint':value.get('logical_state_sha256',value.get('balance_fingerprint'))}

def validate_disk_records(records, task, samples, warmup):
    mode=task['mode']; profile=task['profile']; total=samples+warmup
    metadata=[r for r in records if r.get('record')=='disk_metadata']; assert len(metadata)==1
    metadata=metadata[0]
    assert all(metadata[k]==profile[k] for k in ('N','A','R','K'))
    assert metadata['W']==task['withdrawals'] and metadata['runtime']=='tokio' and metadata['smoke'] is False
    assert metadata['logical_page_bytes']==4084 and metadata['physical_page_bytes']==4096 and metadata['cache_pages']==1024
    assert metadata['native_cache_cleared']==(mode=='disk-receive-first-touch') and metadata['os_cache']=='uncontrolled'
    assert metadata['durability_boundary']=='native_State_commit'
    metrics=[r for r in records if r.get('record')=='disk_metrics']
    correctness=[r for r in records if r.get('record')=='disk_correctness']
    for collection in (metrics,correctness):
        assert len(collection)==total
        for step,record in enumerate(collection):
            assert record['sample']==step and record['epoch']==7+step and record['warmup']==(step<warmup)
            assert record['variant']=='qmdb' and record['mode']==mode
    fields=('scalar_get_calls','batch_get_calls','lookups_requested','storage_reads','storage_read_bytes')
    assert all(all(isinstance(row[field],int) and row[field]>=0 for field in fields) and row['batch_get_calls']>0 and row['counter_deltas'] for row in metrics)
    assert all(delta==0 for row in metrics for series,delta in row['counter_deltas'].items() if 'producer' in series), 'producer activity overlaps receive metrics'
    assert all(row['status']=='ok' and row['root'] and row['operations']>0 for row in correctness)
    assert all(a['operations']<b['operations'] for a,b in zip(correctness,correctness[1:]))
    final=oracle(records); assert final['epochs']==total and final['fingerprint']
    original=[r for r in records if r.get('record')=='oracle'][0]
    assert original['reopened'] is True and original['W']==task['withdrawals'] and original['operations']==correctness[-1]['operations']
    return {'disk_metadata':metadata,'disk_metrics':metrics,'disk_correctness':correctness,'oracle':final,'counter_scope':'whole_receive_through_native_commit; Blob requested calls/bytes, not device reads'}

def execute(args, tasks):
    if platform.system() != 'Linux':
        raise SystemExit('Published timing runner requires the designated external Linux host')
    if not args.external_host:
        raise SystemExit('--external-host is required for execution; use the approved host designation, without credentials')
    if any(t['mode'].startswith('disk-') for t in tasks) and args.disk_root is None:
        raise SystemExit('--disk-root is required for filesystem benchmarks')
    output = args.output.resolve()
    output.mkdir(parents=True,exist_ok=False)
    manifests = {}
    for v in sorted({t['variant'] for t in tasks}):
        manifests[v] = json.loads((ROOT/'bin'/f'{v}.json').read_text())
        assert manifests[v]['binary_sha256']==sha(ROOT/'bin'/v), 'binary differs from build manifest'
    host = {'designation':args.external_host,'hostname':platform.node(),'platform':platform.platform(),'cpus':os.cpu_count(),'sources':manifests,'phase':args.phase,'plan':tasks,'settings':vars(args).copy(),'before':snapshot()}
    host['settings']['output']=str(args.output)
    host['settings']['disk_root']=str(args.disk_root) if args.disk_root else None
    if args.disk_root:
        args.disk_root.mkdir(parents=True,exist_ok=True)
        mount=subprocess.run(['findmnt','--json','--target',str(args.disk_root.resolve())],capture_output=True,text=True,check=True)
        host['filesystem']=json.loads(mount.stdout)
        assert all(item.get('fstype') not in ('tmpfs','ramfs','overlay') for item in host['filesystem']['filesystems']), 'explicit real filesystem required'
    cpuinfo = pathlib.Path('/proc/cpuinfo').read_text()
    host['cpu_models']=sorted({line.split(':',1)[1].strip() for line in cpuinfo.splitlines() if line.startswith('model name')})
    (output/'manifest.json').write_text(json.dumps(host,indent=2)+'\n')
    completed = []
    paired = {}
    for index,t in enumerate(tasks):
        p=t['profile'];variant=t['variant'];mode=t['mode']
        name=f"{index:03d}-{p['id']}-{variant}-{mode}"+(f"-{t['group']}" if t['group'] else '')
        folder=output/name;folder.mkdir()
        env=os.environ.copy()
        env.update({f'COMMONWARE_LATENCY_{key}':str(p[key]) for key in ('N','A','R','K')})
        samples=1 if args.phase=='preflight' else args.samples
        warmup=0 if args.phase=='preflight' else args.warmup
        env.update(COMMONWARE_LATENCY_MODE=mode,COMMONWARE_LATENCY_SAMPLES=str(samples),COMMONWARE_LATENCY_WARMUP=str(warmup),CRITERION_HOME=str(folder/'criterion'))
        cmd=[str(ROOT/'bin'/variant)]
        if mode=='artifact-latency':
            env['COMMONWARE_CLEARING_ARTIFACT']=t['group']
            cmd += ['--test'] if t['smoke'] else ['--bench','--sample-size',str(args.samples),'--warm-up-time','1','--measurement-time','3','--noplot']
        if mode.startswith('disk-'):
            disk_directory=(args.disk_root/output.name/name).resolve()
            assert not disk_directory.exists(), 'disk run directory must be fresh'
            env.update(COMMONWARE_LATENCY_DISK_DIRECTORY=str(disk_directory),COMMONWARE_LATENCY_WITHDRAWALS=str(t['withdrawals']))
        record={'task':t,'command':cmd,'before':snapshot(),'rss_limit_gib':args.rss_limit_gib,'samples':samples,'warmup':warmup}
        (folder/'run.json').write_text(json.dumps(record,indent=2)+'\n')
        print(json.dumps({'start':name}),flush=True)
        started=time.monotonic();peak=0;reason=None
        with (folder/'stdout.log').open('w') as stdout,(folder/'stderr.log').open('w') as stderr:
            process=subprocess.Popen(cmd,env=env,stdout=stdout,stderr=stderr)
            while process.poll() is None:
                try:
                    status=pathlib.Path(f'/proc/{process.pid}/status').read_text()
                    rss=max((int(line.split()[1])*1024 for line in status.splitlines() if line.startswith(('VmRSS:','VmHWM:'))),default=0)
                    peak=max(peak,rss)
                except FileNotFoundError: pass
                if peak > args.rss_limit_gib*1024**3: reason='rss_cap'
                if time.monotonic()-started > args.timeout_seconds: reason='timeout'
                if reason:
                    process.kill();process.wait();break
                time.sleep(1)
        record.update(exit_code=process.returncode,wall_seconds=time.monotonic()-started,peak_observed_rss_bytes=peak,stop_reason=reason,after=snapshot())
        records=json_records(folder/'stdout.log')
        record['artifact_sizes']=artifact_size_records(folder/'stderr.log')
        (folder/'records.json').write_text(json.dumps(records,indent=2)+'\n')
        try:
            assert process.returncode==0 and reason is None, f'child failed: {reason or process.returncode}'
            assert sum(r.get('record')=='complete' for r in records)==1,'missing completion record'
            metadata=[r for r in records if r.get('record')=='metadata'];assert len(metadata)==1
            assert all(metadata[0][k]==p[k] for k in ('N','A','R','K'))
            assert metadata[0]['variant']==variant and metadata[0]['mode']==mode and metadata[0]['workers']==16 and metadata[0]['validators']==100
            if mode!='artifact-latency':
                sequence=[r for r in records if r.get('record')=='sample']
                for step,sample in enumerate(sequence):
                    expected_epoch=7 if mode.startswith('seal') or mode in ('sign-vote','balance-fetch') else 7+step
                    assert sample['sample']==step and sample['epoch']==expected_epoch and sample['warmup']==(step<warmup) and sample['variant']==variant and sample['mode']==mode, 'sample identity/lifetime mismatch'
                measured=[r['nanoseconds'] for r in sequence if not r['warmup']]
                assert len(measured)==samples and all(v>0 for v in measured),'sample count/duration mismatch'
                assert sum(r.get('record')=='sample' and r['warmup'] for r in records)==warmup
                record['timing_ns']={'samples':measured,'median':statistics.median(measured),'min':min(measured),'max':max(measured)}
                if mode=='receive-phases' or mode.startswith('disk-'):
                    expected_phases={'decode','resident-hydrate','verify-and-vote','apply'} if variant=='reference' else {'decode','verify-and-vote','validate-decoded','vote','apply'}
                    if mode.startswith('disk-'): expected_phases={'decode','validate-decoded','vote','apply','commit'}
                    phase_records=[r for r in records if r.get('record')=='phase']
                    assert len(phase_records)==(samples+warmup)*len(expected_phases), 'phase count mismatch'
                    for step,total in enumerate(sequence):
                        parts=[r for r in phase_records if r['sample']==step]
                        assert {r['phase'] for r in parts}==expected_phases and len(parts)==len(expected_phases)
                        assert all(r['mode']==mode and r['variant']==variant and r['epoch']==7+step and r['warmup']==(step<warmup) and 0<=r['nanoseconds']<=total['nanoseconds'] for r in parts)
                    record['phase_timings_ns']={name:[r['nanoseconds'] for r in phase_records if r['phase']==name and not r['warmup']] for name in sorted(expected_phases)}
                if mode.startswith('disk-'):
                    record.update(validate_disk_records(records,t,samples,warmup))
                if mode in ('prepare-apply','receive-apply','receive-phases'):
                    state=oracle(records);assert state['epochs']==samples+warmup and state['fingerprint']
                    record['oracle']=state
                    key=(p['id'],mode)
                    if key in paired: assert paired[key]==state, 'cross-variant logical state fingerprint mismatch'
                    else: paired[key]=state
            elif not t['smoke']:
                raw=list((folder/'criterion').glob('**/new/sample.json'))
                assert raw, 'Criterion produced no raw samples'
                observed=[]
                for path in raw:
                    data=json.loads(path.read_text());assert len(data['iters'])>=10 and len(data['times'])==len(data['iters'])
                    identity=json.loads(path.with_name('benchmark.json').read_text())['full_id']
                    observed.append(artifact_case(identity))
                expected=expected_artifact_cases(t)
                assert len(observed)==len(set(observed)) and set(observed)==expected, f'artifact coverage mismatch: expected {len(expected)}, observed {len(observed)}'
                record['criterion_cases']=len(raw)
                record['verified_case_identities']=sorted(observed)
            record['validation']='passed'
        except (AssertionError,KeyError,ValueError) as error:
            record['validation']=str(error)
            (folder/'run.json').write_text(json.dumps(record,indent=2)+'\n')
            raise SystemExit(f'{name}: {error}; preserve failed process artifacts')
        (folder/'run.json').write_text(json.dumps(record,indent=2)+'\n')
        completed.append(record)
        (output/'results.json').write_text(json.dumps(completed,indent=2)+'\n')
        print(json.dumps({'complete':name,'wall_seconds':record['wall_seconds'],'rss_bytes':peak}),flush=True)
    (output/'complete.json').write_text(json.dumps({'runs':len(completed),'after':snapshot()},indent=2)+'\n')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase',choices=['preflight','close','close-profiled','prepare','prepare-essential','receive-essential','phases','seal-matched','balance-fetch','artifacts','seal','concentrated','certificate','disk','disk-withdrawals'],required=True)
    p.add_argument('--execute',action='store_true',help='execute only on the designated external host; otherwise print the plan')
    p.add_argument('--external-host');p.add_argument('--output',type=pathlib.Path,required=True)
    p.add_argument('--disk-root',type=pathlib.Path)
    p.add_argument('--samples',type=int,default=10);p.add_argument('--warmup',type=int,default=1)
    p.add_argument('--rss-limit-gib',type=float,default=24);p.add_argument('--timeout-seconds',type=int,default=1800)
    p.add_argument('--profile',action='append');p.add_argument('--variant',choices=['reference','qmdb'],action='append');p.add_argument('--mode',action='append')
    a=p.parse_args()
    if a.samples<10 or a.warmup<0:p.error('published runs require >=10 samples and nonnegative warmup; preflight uses 1/0 automatically')
    tasks=plan(a)
    if not tasks:p.error('empty plan')
    if a.execute:execute(a,tasks)
    else:print(json.dumps({'phase':a.phase,'runs':len(tasks),'tasks':tasks},indent=2))
if __name__=='__main__':main()
