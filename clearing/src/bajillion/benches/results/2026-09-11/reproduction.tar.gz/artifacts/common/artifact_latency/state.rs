use commonware_codec::{Decode, Encode};
use criterion::Criterion;
use std::{fmt::Debug, hint::black_box};

pub(crate) fn bench_artifact<T: Encode + Decode + Eq + Debug>(
    c: &mut Criterion,
    labels: &str,
    kind: &str,
    artifact: &T,
    config: &T::Cfg,
    verify: impl Fn(&T),
) {
    let wire = artifact.encode();
    assert_eq!(wire.len(), artifact.encode_size());
    let decoded = T::decode_cfg(wire.clone(), config).expect("complete state artifact decodes");
    assert_eq!(&decoded, artifact);
    verify(&decoded);
    eprintln!(
        "artifact bytes: artifact=state {labels} kind={kind} bytes={}",
        wire.len()
    );
    c.bench_function(
        &format!("{}::verify/{labels} kind={kind}", module_path!()),
        |b| b.iter(|| verify(black_box(artifact))),
    );
    c.bench_function(
        &format!("{}::receive/{labels} kind={kind}", module_path!()),
        |b| {
            b.iter(|| {
                let decoded = T::decode_cfg(black_box(wire.clone()), black_box(config))
                    .expect("complete state artifact decodes");
                verify(black_box(&decoded));
            })
        },
    );
}
