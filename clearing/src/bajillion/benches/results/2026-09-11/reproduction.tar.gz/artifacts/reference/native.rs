use super::super::{
    admission_fixtures::Validators,
    fixtures::{ActiveProfile, CloseFixture, active_close_fixture_with_assignment},
};
use commonware_clearing::bajillion::{
    challenge::{Challenge, Verdict, adjudicate},
    transition::{CloseContext, Header, RootBundle},
};
use commonware_cryptography::{Sha256, sha256::Digest};
use commonware_cryptography_curve25519::signing::StrictVerifyingKey as Key;

pub(crate) fn build<T>(
    profile: ActiveProfile,
    state: bool,
    extract: impl FnOnce(&CloseFixture) -> T,
) -> (T, Vec<super::native_state::Fixture>) {
    let validators = Validators::new();
    let fixture = active_close_fixture_with_assignment(profile, validators.assignment());
    let artifacts = extract(&fixture);
    let states = if state {
        super::native_state::fixtures(fixture)
    } else {
        drop(fixture);
        Vec::new()
    };
    (artifacts, states)
}

pub(crate) fn closing_amount(fixture: &CloseFixture) -> u64 {
    fixture.prepared.close().rows[1].successor.balance
}

pub(crate) struct ChallengeContext {
    context: CloseContext<Key, Digest>,
    header: Header<Digest>,
    roots: RootBundle<Digest>,
}

impl ChallengeContext {
    pub(crate) fn new(fixture: &CloseFixture) -> Self {
        let close = fixture.prepared.close();
        Self {
            context: fixture.context.clone(),
            header: close.header,
            roots: close.roots,
        }
    }

    pub(crate) fn adjudicate(&self, challenge: &Challenge<Key, Digest>) -> Verdict {
        adjudicate::<Sha256, _, _>(&self.context, &self.header, &self.roots, challenge)
            .expect("challenge is well formed")
    }
}
