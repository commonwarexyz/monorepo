use super::fixtures::{ActiveProfile, selected_active_profiles};
use criterion::Criterion;
use std::time::Duration;

mod acceptance;
mod challenge;
mod native;
mod native_certified;
mod native_state;
mod state;
mod withdrawal;

fn labels(profile: ActiveProfile) -> String {
    format!(
        "N={} A={} R={} K={} validators=100 workers=16",
        profile.live_accounts, profile.senders, profile.credited_accounts, profile.out_degree,
    )
}

pub(crate) fn benches() {
    let selected = std::env::var("COMMONWARE_CLEARING_ARTIFACT").unwrap_or_else(|_| "all".into());
    assert!(matches!(
        selected.as_str(),
        "all" | "challenge" | "withdrawal" | "acceptance" | "state" | "certificate"
    ));
    let mut criterion = Criterion::default()
        .sample_size(10)
        .warm_up_time(Duration::from_secs(1))
        .measurement_time(Duration::from_secs(3))
        .configure_from_args();
    if selected == "certificate" {
        native_certified::bench(&mut criterion);
        return;
    }
    for (_, profile) in selected_active_profiles() {
        assert!(profile.live_accounts >= 4 && profile.senders >= 4);
        assert_eq!(super::admission_fixtures::VALIDATORS, 100);
        assert_eq!(super::fixtures::WORKERS, 16);
        let ((challenges, acceptance, withdrawals), states) = native::build(
            profile,
            matches!(selected.as_str(), "all" | "state"),
            |fixture| {
                let challenges = matches!(selected.as_str(), "all" | "challenge")
                    .then(|| challenge::fixture(fixture));
                let acceptance = matches!(selected.as_str(), "all" | "acceptance")
                    .then(|| acceptance::fixture(fixture));
                let withdrawals = matches!(selected.as_str(), "all" | "withdrawal")
                    .then(|| withdrawal::fixtures(fixture, profile));
                (challenges, acceptance, withdrawals)
            },
        );
        let labels = labels(profile);
        if let Some(challenges) = challenges {
            challenge::bench(&mut criterion, &labels, challenges);
        }
        if let Some(acceptance) = acceptance {
            acceptance::bench(&mut criterion, &labels, acceptance);
        }
        if let Some(withdrawals) = withdrawals {
            withdrawal::bench(&mut criterion, &labels, withdrawals);
        }
        native_state::bench(&mut criterion, &labels, states);
    }
}
