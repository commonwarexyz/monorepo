use super::{
    super::fixtures::{CloseFixture, strategy},
    state::bench_artifact,
};
use commonware_clearing::bajillion::{
    challenge::{StateLookup, StateOpening},
    commitment::{VectorKind, VectorRoot},
    state::StateLeaf,
    transition::StateCache,
};
use commonware_codec::Encode;
use commonware_cryptography::{Sha256, Signer as _, sha256::Digest};
use commonware_cryptography_curve25519::signing::{SigningKey, StrictVerifyingKey as Key};
use criterion::Criterion;
use std::hint::black_box;

pub(crate) struct Fixture {
    context: &'static str,
    root: VectorRoot<Digest>,
    account: Key,
    missing: Key,
    opening: StateOpening<Key, Digest>,
    present: StateLookup<Key, Digest>,
    absent: StateLookup<Key, Digest>,
}

fn from_cache(
    context: &'static str,
    cache: &StateCache<Key, Digest>,
    account: &Key,
    missing: &Key,
) -> Fixture {
    Fixture {
        context,
        root: cache.root(),
        account: account.clone(),
        missing: missing.clone(),
        opening: cache.opening(account).expect("account opens"),
        present: cache.lookup(account).expect("membership"),
        absent: cache.lookup(missing).expect("exclusion"),
    }
}

pub(crate) fn fixtures(fixture: CloseFixture) -> Vec<Fixture> {
    let account = fixture.accounts[fixture.accounts.len() / 2].0.clone();
    let missing = SigningKey::from_seed(u64::MAX).public_key();
    let predecessor = from_cache("predecessor", &fixture.cache, &account, &missing);
    let close = fixture.prepared.close();
    let mut leaves = close.unchanged.clone();
    leaves.extend(
        close
            .rows
            .iter()
            .filter(|row| row.successor.active)
            .map(|row| StateLeaf {
                account: row.account.clone(),
                state: row.successor,
            }),
    );
    leaves.sort_unstable_by(|left, right| left.account.cmp(&right.account));
    let successor_cache = StateCache::new_with_strategy::<Sha256>(leaves, strategy())
        .expect("native successor cache");
    assert_eq!(successor_cache.root(), close.roots.successor);
    let successor = from_cache(
        "successor_after_apply",
        &successor_cache,
        &account,
        &missing,
    );
    let historical = from_cache(
        "retained_predecessor_after_apply",
        &fixture.cache,
        &account,
        &missing,
    );
    assert_eq!(historical.opening, predecessor.opening);
    assert_eq!(historical.present, predecessor.present);
    assert_eq!(historical.absent, predecessor.absent);
    vec![predecessor, successor, historical]
}

pub(crate) fn bench(c: &mut Criterion, labels: &str, fixtures: Vec<Fixture>) {
    for fixture in fixtures {
        let labels = format!(
            "{labels} context={} contract=state_cache_bmt",
            fixture.context
        );
        let root = &fixture.root;
        assert!(matches!(fixture.present, StateLookup::Present(_)));
        assert!(matches!(fixture.absent, StateLookup::Absent(_)));
        assert_eq!(
            fixture
                .present
                .resolve::<Sha256>(root, &fixture.account)
                .expect("present verifies"),
            Some(fixture.opening.leaf.state)
        );
        assert_eq!(
            fixture
                .absent
                .resolve::<Sha256>(root, &fixture.missing)
                .expect("absence verifies"),
            None
        );
        bench_artifact(c, &labels, "opening", &fixture.opening, &(), |opening| {
            opening
                .proof
                .verify::<Sha256>(
                    VectorKind::State,
                    black_box(root),
                    opening.leaf.encode().as_ref(),
                )
                .expect("state leaf opening verifies");
        });
        for (kind, lookup, account) in [
            ("present", &fixture.present, &fixture.account),
            ("absent", &fixture.absent, &fixture.missing),
        ] {
            bench_artifact(c, &labels, kind, lookup, &(), |lookup| {
                black_box(
                    lookup
                        .resolve::<Sha256>(black_box(root), black_box(account))
                        .expect("lookup verifies"),
                );
            });
        }
    }
}
