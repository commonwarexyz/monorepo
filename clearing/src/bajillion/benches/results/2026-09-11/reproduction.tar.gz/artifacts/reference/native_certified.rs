use super::{
    super::{admission_fixtures::Validators, fixtures::ActiveProfile},
    native,
};
use commonware_clearing::bajillion::admission::bls12381;
use commonware_codec::Encode;
use commonware_cryptography::Sha256;
use commonware_utils::Participant;
use criterion::Criterion;
use std::hint::black_box;

pub(crate) fn bench(c: &mut Criterion) {
    let profile = ActiveProfile {
        live_accounts: 1024,
        senders: 1024,
        credited_accounts: 512,
        out_degree: 1,
    };
    let ((context, deposits, withdrawals, header, roots, terminal, certificate, verifier), _) =
        native::build(profile, false, |fixture| {
            let validators = Validators::new();
            let close = fixture.prepared.close();
            let certificate = validators
                .signer(Participant::from_usize(0))
                .assemble_exact(validators.attestations(&close.header))
                .expect("exact certificate");
            let verifier = bls12381::Scheme::verifier(validators.committee().clone());
            let terminal = fixture
                .prepared
                .terminal_proof()
                .expect("native terminal proof");
            (
                fixture.context.clone(),
                fixture.deposits.clone(),
                fixture.withdrawals.clone(),
                close.header,
                close.roots,
                terminal,
                certificate,
                verifier,
            )
        });
    let certified_bytes = (header, certificate.clone()).encode().len();
    assert_eq!(certified_bytes, 101);
    let witness_bytes = (header, roots, terminal.clone(), certificate.clone())
        .encode()
        .len();
    eprintln!(
        "artifact bytes: artifact=native_certified n=100 f=33 q=67 fixture_N=1024 contract=terminal_proof bytes={certified_bytes} certified_commitment_bytes={certified_bytes} fullwitness_bytes={witness_bytes} header_roots_terminal_certificate_bytes={witness_bytes}"
    );
    let verify_certified_commitment = || {
        terminal
            .verify::<Sha256, _>(
                black_box(&context),
                black_box(&deposits),
                black_box(&withdrawals),
                black_box(&header),
                black_box(&roots),
            )
            .expect("terminal proof and registered boundaries verify");
        assert!(verifier.verify_exact(black_box(&header), black_box(&certificate)));
        header.batch_id::<Sha256>()
    };
    assert_eq!(verify_certified_commitment(), header.batch_id::<Sha256>());
    c.bench_function(
        &format!(
            "{}::verify_certified_commitment/n=100 f=33 q=67 contract=terminal_proof",
            module_path!()
        ),
        |b| b.iter(|| black_box(verify_certified_commitment())),
    );
}
