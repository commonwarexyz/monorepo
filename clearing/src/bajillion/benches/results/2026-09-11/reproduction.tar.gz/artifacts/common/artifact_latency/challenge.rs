use super::{
    super::fixtures::{CloseFixture, kind_label, proven_challenges},
    native::ChallengeContext,
};
use commonware_clearing::bajillion::challenge::{
    Challenge, ChallengeKind, Verdict, decode_bounded,
};
use commonware_codec::{Encode, EncodeSize};
use commonware_cryptography::sha256::Digest;
use commonware_cryptography_curve25519::signing::StrictVerifyingKey as Key;
use criterion::Criterion;
use std::hint::black_box;

pub(crate) struct Fixture {
    context: ChallengeContext,
    cases: [(ChallengeKind, Challenge<Key, Digest>); 3],
}

pub(crate) fn fixture(close: &CloseFixture) -> Fixture {
    Fixture {
        context: ChallengeContext::new(close),
        cases: proven_challenges(close),
    }
}

pub(crate) fn bench(c: &mut Criterion, labels: &str, fixture: Fixture) {
    for (kind, challenge) in fixture.cases {
        let wire = challenge.encode();
        assert_eq!(wire.len(), challenge.encode_size());
        let decoded = decode_bounded::<Key, Digest>(wire.as_ref(), wire.len())
            .expect("bounded challenge decodes");
        assert_eq!(decoded, challenge);
        assert_eq!(fixture.context.adjudicate(&decoded), Verdict::Proven(kind));
        eprintln!(
            "artifact bytes: artifact=challenge {labels} kind={} bytes={}",
            kind_label(kind),
            wire.len(),
        );
        c.bench_function(
            &format!(
                "{}::verify/{labels} kind={}",
                module_path!(),
                kind_label(kind)
            ),
            |b| b.iter(|| black_box(black_box(&fixture.context).adjudicate(black_box(&challenge)))),
        );
        c.bench_function(
            &format!(
                "{}::receive/{labels} kind={}",
                module_path!(),
                kind_label(kind)
            ),
            |b| {
                b.iter(|| {
                    let decoded = decode_bounded::<Key, Digest>(
                        black_box(wire.as_ref()),
                        black_box(wire.len()),
                    )
                    .expect("bounded challenge decodes");
                    black_box(black_box(&fixture.context).adjudicate(black_box(&decoded)))
                })
            },
        );
    }
}
