use super::{
    super::fixtures::{ActiveProfile, CloseFixture, strategy},
    native,
};
use bytes::Bytes;
use commonware_clearing::bajillion::{
    boundary::{SignedWithdrawal, WithdrawalAction},
    commitment::{Builder, VectorKind, VectorRoot},
    transition::{WithdrawalClaim, WithdrawalOutput},
};
use commonware_codec::{Decode, Encode, EncodeSize, RangeCfg};
use commonware_cryptography::{Sha256, sha256::Digest};
use criterion::Criterion;
use std::{hint::black_box, num::NonZeroU64};

const DESTINATION: &[u8] = b"benchmark-destination";

pub(crate) struct Fixture {
    total: u32,
    action: &'static str,
    depth: usize,
    root: VectorRoot<Digest>,
    claim: WithdrawalClaim<Digest>,
}

// This standalone tree measures an output opening; its fillers are not a withdrawal batch.
fn fixture(close: &CloseFixture, total: u32, action: WithdrawalAction) -> Fixture {
    let row = &close.prepared.close().rows[1];
    let signer = &close
        .accounts
        .iter()
        .find(|(key, _)| key == &row.account)
        .expect("claimed account is registered")
        .1;
    let (label, amount) = match action {
        WithdrawalAction::Amount(amount) => ("amount", amount.get()),
        WithdrawalAction::Close => ("close", native::closing_amount(close)),
    };
    assert!(amount > 0);
    let request = SignedWithdrawal::sign(
        *close.context.deployment(),
        close.context.predecessor_root().digest,
        Bytes::from_static(DESTINATION),
        action,
        100,
        signer,
    );
    request.verify_signature().expect("signed request verifies");
    let output = WithdrawalOutput::decode_cfg(
        (request.body().destination().clone(), amount).encode(),
        &RangeCfg::exact(DESTINATION.len()),
    )
    .expect("claim output decodes");
    let position = total / 2;
    let outputs = (0..total)
        .map(|index| {
            if index == position {
                return output.clone();
            }
            let destination = Bytes::from(format!("exit-{index:016}").into_bytes());
            assert_eq!(destination.len(), DESTINATION.len());
            WithdrawalOutput::decode_cfg(
                (destination, u64::from(index) + 1).encode(),
                &RangeCfg::exact(DESTINATION.len()),
            )
            .expect("filler output decodes")
        })
        .collect::<Vec<_>>();
    let mut builder =
        Builder::<Sha256>::new(VectorKind::WithdrawalOutput, total).expect("valid output count");
    builder
        .add_values(&outputs, strategy())
        .expect("outputs commit");
    let tree = builder.build(strategy()).expect("output tree builds");
    let opening = tree.opening(position).expect("output opens");
    let depth = opening.proof.siblings.len();
    assert_eq!(opening.proof.leaf_count, total);
    assert_eq!(depth, (u32::BITS - (total - 1).leading_zeros()) as usize);
    let wire = (output.clone(), opening).encode();
    let claim =
        WithdrawalClaim::<Digest>::decode_cfg(wire.clone(), &RangeCfg::exact(DESTINATION.len()))
            .expect("complete claim decodes");
    assert_eq!(claim.encode(), wire);
    assert_eq!(claim.position(), position);
    assert_eq!(
        claim
            .verify::<Sha256>(&tree.root())
            .expect("claim verifies"),
        output
    );
    Fixture {
        total,
        action: label,
        depth,
        root: tree.root(),
        claim,
    }
}

pub(crate) fn fixtures(close: &CloseFixture, profile: ActiveProfile) -> Vec<Fixture> {
    let n = u32::try_from(profile.live_accounts).expect("output count fits u32");
    let mut totals = vec![1, 8, 64, 512, 1_024, 10_000, 100_000, 1_000_000, n];
    totals.retain(|total| *total <= n);
    totals.sort_unstable();
    totals.dedup();
    totals
        .into_iter()
        .flat_map(|total| {
            [
                WithdrawalAction::Amount(NonZeroU64::MIN),
                WithdrawalAction::Close,
            ]
            .map(|action| fixture(close, total, action))
        })
        .collect()
}

pub(crate) fn bench(c: &mut Criterion, labels: &str, fixtures: Vec<Fixture>) {
    for Fixture {
        total,
        action,
        depth,
        root,
        claim,
    } in fixtures
    {
        let wire = claim.encode();
        assert_eq!(wire.len(), claim.encode_size());
        eprintln!(
            "artifact bytes: artifact=withdrawal fixture=standalone_output_tree {labels} W={total} action={action} depth={depth} position={} bytes={}",
            claim.position(),
            wire.len(),
        );
        c.bench_function(
            &format!(
                "{}::verify/{labels} W={total} action={action} fixture=standalone_output_tree",
                module_path!()
            ),
            |b| {
                b.iter(|| {
                    black_box(
                        black_box(&claim)
                            .verify::<Sha256>(black_box(&root))
                            .expect("claim verifies"),
                    )
                })
            },
        );
        c.bench_function(
            &format!(
                "{}::receive/{labels} W={total} action={action} fixture=standalone_output_tree",
                module_path!()
            ),
            |b| {
                b.iter(|| {
                    let decoded = WithdrawalClaim::<Digest>::decode_cfg(
                        black_box(wire.clone()),
                        &RangeCfg::exact(DESTINATION.len()),
                    )
                    .expect("complete claim decodes");
                    black_box(
                        decoded
                            .verify::<Sha256>(black_box(&root))
                            .expect("claim verifies"),
                    )
                })
            },
        );
    }
}
