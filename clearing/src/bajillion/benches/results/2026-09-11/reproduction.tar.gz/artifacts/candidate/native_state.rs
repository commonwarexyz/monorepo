use super::{super::fixtures::CloseFixture, state::bench_artifact};
use commonware_clearing::bajillion::qmdb::{
    AccountKey, StateLookup, StateOpening, StateRoot, account_key,
};
use commonware_codec::EncodeSize;
use commonware_cryptography::{Sha256, Signer as _, sha256::Digest};
use commonware_cryptography_curve25519::signing::{SigningKey, StrictVerifyingKey as Key};
use criterion::Criterion;
use std::hint::black_box;

pub(crate) struct Fixture {
    context: &'static str,
    root: StateRoot<Digest>,
    key: AccountKey,
    missing: AccountKey,
    opening: StateOpening<Key, Digest>,
    present: StateLookup<Digest>,
    absent: StateLookup<Digest>,
}

pub(crate) async fn fixtures(fixture: CloseFixture) -> Vec<Fixture> {
    let account = fixture.accounts[fixture.accounts.len() / 2].0.clone();
    let key = account_key(&account).expect("account key");
    let missing = account_key(&SigningKey::from_seed(u64::MAX).public_key()).expect("missing key");
    let root = fixture.state.root();
    let operations = fixture.state.head().operations();
    let predecessor = Fixture {
        context: "predecessor",
        root,
        key: key.clone(),
        missing: missing.clone(),
        opening: fixture
            .state
            .opening(account.clone())
            .await
            .expect("opening"),
        present: fixture.state.lookup(&key).await.expect("membership"),
        absent: fixture.state.lookup(&missing).await.expect("exclusion"),
    };
    let (state, _) = fixture
        .prepared
        .apply(fixture.state)
        .await
        .expect("close applies");
    let successor = Fixture {
        context: "successor_after_apply",
        root: state.root(),
        key: key.clone(),
        missing: missing.clone(),
        opening: state
            .opening(account.clone())
            .await
            .expect("successor opening"),
        present: state.lookup(&key).await.expect("successor membership"),
        absent: state.lookup(&missing).await.expect("successor exclusion"),
    };
    let historical = Fixture {
        context: "historical_predecessor_after_apply",
        root,
        key: key.clone(),
        missing: missing.clone(),
        opening: state
            .opening_at(root, operations, account)
            .await
            .expect("historical opening"),
        present: state
            .lookup_at(root, operations, &key)
            .await
            .expect("historical membership"),
        absent: state
            .lookup_at(root, operations, &missing)
            .await
            .expect("historical exclusion"),
    };
    assert_eq!(historical.opening.account, predecessor.opening.account);
    assert_eq!(historical.opening.balance, predecessor.opening.balance);
    assert_eq!(state.root(), successor.root);
    vec![predecessor, successor, historical]
}

pub(crate) fn bench(c: &mut Criterion, labels: &str, fixtures: Vec<Fixture>) {
    for fixture in fixtures {
        let labels = format!("{labels} context={} contract=current_mmb", fixture.context);
        let root = &fixture.root;
        let expected = fixture.opening.balance;
        assert!(matches!(fixture.present, StateLookup::Present(_)));
        assert!(matches!(fixture.absent, StateLookup::Absent(_)));
        assert_eq!(
            fixture
                .opening
                .verify::<Sha256>(root)
                .expect("opening verifies"),
            expected
        );
        assert_eq!(
            fixture
                .present
                .resolve::<Sha256>(root, &fixture.key)
                .expect("present verifies"),
            Some(expected)
        );
        assert_eq!(
            fixture
                .absent
                .resolve::<Sha256>(root, &fixture.missing)
                .expect("absence verifies"),
            None
        );
        bench_artifact(
            c,
            &labels,
            "opening",
            &fixture.opening,
            &fixture.opening.encode_size(),
            |opening| {
                black_box(
                    opening
                        .verify::<Sha256>(black_box(root))
                        .expect("opening verifies"),
                );
            },
        );
        for (kind, lookup, key) in [
            ("present", &fixture.present, &fixture.key),
            ("absent", &fixture.absent, &fixture.missing),
        ] {
            bench_artifact(c, &labels, kind, lookup, &lookup.encode_size(), |lookup| {
                black_box(
                    lookup
                        .resolve::<Sha256>(black_box(root), black_box(key))
                        .expect("lookup verifies"),
                );
            });
        }
    }
}
