use super::super::fixtures::{ActiveProfile, CloseFixture, active_close_fixture, runner};
use commonware_clearing::bajillion::{
    challenge::{Challenge, Verdict, adjudicate},
    transition::{CloseAmounts, CloseContext, Header, RootBundle},
};
use commonware_cryptography::{Sha256, sha256::Digest};
use commonware_cryptography_curve25519::signing::StrictVerifyingKey as Key;
use commonware_runtime::Runner as _;

pub(crate) fn build<T>(
    profile: ActiveProfile,
    state: bool,
    extract: impl FnOnce(&CloseFixture) -> T,
) -> (T, Vec<super::native_state::Fixture>) {
    runner().start(|runtime| async move {
        let fixture = active_close_fixture(runtime, profile).await;
        let artifacts = extract(&fixture);
        let states = if state {
            super::native_state::fixtures(fixture).await
        } else {
            drop(fixture);
            Vec::new()
        };
        (artifacts, states)
    })
}

pub(crate) fn closing_amount(fixture: &CloseFixture) -> u64 {
    fixture.prepared.close().rows[1].successor
}

pub(crate) struct ChallengeContext {
    context: CloseContext<Key, Digest>,
    header: Header<Digest>,
    roots: RootBundle<Digest>,
    amounts: CloseAmounts,
}

impl ChallengeContext {
    pub(crate) fn new(fixture: &CloseFixture) -> Self {
        let close = fixture.prepared.close();
        Self {
            context: fixture.context.clone(),
            header: close.header,
            roots: close.roots,
            amounts: close.amounts,
        }
    }

    pub(crate) fn adjudicate(&self, challenge: &Challenge<Key, Digest>) -> Verdict {
        adjudicate::<Sha256, _, _>(
            &self.context,
            &self.header,
            &self.roots,
            &self.amounts,
            challenge,
        )
        .expect("challenge is well formed")
    }
}
