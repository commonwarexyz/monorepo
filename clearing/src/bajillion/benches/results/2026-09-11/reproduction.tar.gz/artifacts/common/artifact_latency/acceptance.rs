use super::super::fixtures::CloseFixture;
use commonware_clearing::bajillion::{
    payment::{EntryReceipt, PaymentContext, SendAuthorization, VectorAck},
    vector::OutTipLookup,
};
use commonware_codec::{Decode, Encode};
use commonware_cryptography::{Sha256, sha256::Digest};
use commonware_cryptography_curve25519::signing::StrictVerifyingKey as Key;
use criterion::Criterion;
use std::{fmt::Debug, hint::black_box};

pub(crate) struct Fixture {
    context: PaymentContext<Key, Digest>,
    receipt: EntryReceipt<Key, Digest>,
    authorization: SendAuthorization<Key, Digest>,
    ack: VectorAck<Key, Digest>,
}

pub(crate) fn fixture(close: &CloseFixture) -> Fixture {
    let ack = close.acks[3].clone();
    let vector = close
        .prepared
        .close()
        .out_vectors
        .iter()
        .find(|vector| vector.payer() == ack.body().payer())
        .expect("receipt payer has a committed vector");
    let recipient = vector.entries()[0].recipient.clone();
    let OutTipLookup::Present {
        cumulative,
        count,
        opening,
    } = vector
        .lookup::<Sha256, Digest>(&recipient)
        .expect("entry lookup")
    else {
        panic!("receipt entry is present");
    };
    let receipt = EntryReceipt {
        ack: ack.clone(),
        recipient,
        cumulative,
        count,
        opening,
    };
    let authorization =
        SendAuthorization::from_raw_unchecked(ack.body().clone(), ack.payer_signature().clone());
    Fixture {
        context: close.context.payment().clone(),
        receipt,
        authorization,
        ack,
    }
}

fn bench_artifact<T: Encode + Decode<Cfg = ()> + Eq + Debug>(
    c: &mut Criterion,
    labels: &str,
    kind: &str,
    artifact: &T,
    verify: impl Fn(&T),
) {
    let wire = artifact.encode();
    assert_eq!(wire.len(), artifact.encode_size());
    let decoded = T::decode_cfg(wire.clone(), &()).expect("complete artifact decodes");
    assert_eq!(&decoded, artifact);
    verify(&decoded);
    eprintln!(
        "artifact bytes: artifact=acceptance {labels} kind={kind} bytes={}",
        wire.len()
    );
    c.bench_function(
        &format!("{}::verify/{labels} kind={kind}", module_path!()),
        |b| b.iter(|| verify(black_box(artifact))),
    );
    c.bench_function(
        &format!("{}::receive/{labels} kind={kind}", module_path!()),
        |b| {
            b.iter(|| {
                let decoded =
                    T::decode_cfg(black_box(wire.clone()), &()).expect("complete artifact decodes");
                verify(black_box(&decoded));
            })
        },
    );
}

pub(crate) fn bench(c: &mut Criterion, labels: &str, fixture: Fixture) {
    bench_artifact(c, labels, "receipt", &fixture.receipt, |receipt| {
        receipt
            .verify::<Sha256>(black_box(&fixture.context))
            .expect("receipt verifies");
    });
    bench_artifact(c, labels, "ack", &fixture.ack, |ack| {
        ack.verify(black_box(&fixture.context))
            .expect("ack verifies");
    });
    bench_artifact(
        c,
        labels,
        "authorization",
        &fixture.authorization,
        |authorization| {
            authorization
                .verify(black_box(&fixture.context))
                .expect("authorization verifies");
        },
    );
}
