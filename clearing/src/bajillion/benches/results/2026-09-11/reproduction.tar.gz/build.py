#!/usr/bin/env python3
"""Install benchmark-only overlays in disposable source snapshots and build, never time."""
import argparse,hashlib,json,os,pathlib,shutil,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
PINS={'reference':'3a3b934662d1d590ea553b8734d241041b6b8182','qmdb':'b93fed3ae2ad75d2ceafa9db7545b381d1e875c4'}
PROFILE='''
pub(crate) fn latency_profile() -> ActiveProfile {
    let read=|name:&str| std::env::var(name).expect(name).parse::<usize>().expect("profile integer");
    let p=ActiveProfile {live_accounts:read("COMMONWARE_LATENCY_N"),senders:read("COMMONWARE_LATENCY_A"),credited_accounts:read("COMMONWARE_LATENCY_R"),out_degree:read("COMMONWARE_LATENCY_K")};
    assert!(p.live_accounts>=4 && p.senders>=4 && p.senders<=p.live_accounts && p.credited_accounts>0 && p.credited_accounts<=p.live_accounts && p.out_degree>0 && p.out_degree<=p.credited_accounts);
    p
}
'''
MAIN='''#![allow(dead_code,unused_imports)]
mod admission_fixtures;
mod fixtures;
mod artifact_latency;
mod LATENCY_MODULE;
const VARIANT:&str="VARIANT_VALUE";
fn emit_sample(mode:&str,step:usize,warmup:usize,elapsed:std::time::Duration){
 let epoch=if mode.starts_with("seal") || matches!(mode,"sign-vote"|"balance-fetch") {7}else{7+step};
 println!("{{\\"record\\":\\"sample\\",\\"variant\\":\\"{}\\",\\"mode\\":\\"{}\\",\\"epoch\\":{},\\"sample\\":{},\\"warmup\\":{},\\"nanoseconds\\":{}}}",VARIANT,mode,epoch,step,step<warmup,elapsed.as_nanos());
 std::io::Write::flush(&mut std::io::stdout()).unwrap();
}
fn emit_phase(mode:&str,phase:&str,step:usize,warmup:usize,elapsed:std::time::Duration){
 println!("{{\\"record\\":\\"phase\\",\\"variant\\":\\"{}\\",\\"mode\\":\\"{}\\",\\"phase\\":\\"{}\\",\\"epoch\\":{},\\"sample\\":{},\\"warmup\\":{},\\"nanoseconds\\":{}}}",VARIANT,mode,phase,7+step,step,step<warmup,elapsed.as_nanos());
}
fn main(){
 let mode=std::env::var("COMMONWARE_LATENCY_MODE").expect("mode");
 let read=|name:&str,default:usize|std::env::var(name).map(|x|x.parse::<usize>().unwrap()).unwrap_or(default);
 let samples=read("COMMONWARE_LATENCY_SAMPLES",10);let warmup=read("COMMONWARE_LATENCY_WARMUP",1);assert!(samples>0);
 let p=fixtures::latency_profile();
 println!("{{\\"record\\":\\"metadata\\",\\"variant\\":\\"{}\\",\\"mode\\":\\"{}\\",\\"N\\":{},\\"A\\":{},\\"R\\":{},\\"K\\":{},\\"workers\\":16,\\"validators\\":100,\\"samples\\":{},\\"warmup\\":{}}}",VARIANT,mode,p.live_accounts,p.senders,p.credited_accounts,p.out_degree,samples,warmup);
 if mode=="artifact-latency" {artifact_latency::benches();} else {LATENCY_MODULE::run(&mode,samples,warmup);}
 println!("{{\\"record\\":\\"complete\\",\\"variant\\":\\"{}\\",\\"mode\\":\\"{}\\"}}",VARIANT,mode);
}
'''
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source_hashes(source):
 result={}
 for parent,dirs,files in os.walk(source):
  dirs[:]=sorted(d for d in dirs if d not in {'.git','target','benches_latency','node_modules'})
  for name in sorted(files):
   path=pathlib.Path(parent)/name
   if path.suffix=='.rs' or name in {'Cargo.toml','Cargo.lock','rust-toolchain.toml'}:
    result[str(path.relative_to(source))]=sha(path)
 return result

def install(source,variant):
 if (source/'.git').exists():raise SystemExit('Refusing production/git checkout: export a disposable source snapshot first')
 package=source/'clearing';dst=package/'src/bajillion/benches_latency'
 if dst.exists():shutil.rmtree(dst)
 shutil.copytree(package/'src/bajillion/benches',dst)
 fixture=dst/'fixtures.rs';s=fixture.read_text();needle='pub(crate) fn selected_active_profiles() -> Vec<(usize, ActiveProfile)> {'
 assert needle in s
 s=s.replace(needle,needle+'\n    if std::env::var_os("COMMONWARE_LATENCY_N").is_some() { return vec![(0,latency_profile())]; }',1)
 s+=PROFILE;fixture.write_text(s)
 common=ROOT/'artifacts/common';shutil.copy2(common/'artifact_latency.rs',dst/'artifact_latency.rs');shutil.copytree(common/'artifact_latency',dst/'artifact_latency',dirs_exist_ok=True)
 for native in (ROOT/'artifacts'/('candidate' if variant=='qmdb' else 'reference')).glob('native*.rs'): shutil.copy2(native,dst/'artifact_latency'/native.name)
 module='latency_candidate' if variant=='qmdb' else 'latency_reference';shutil.copy2(ROOT/('candidate' if variant=='qmdb' else 'reference')/(module+'.rs'),dst/(module+'.rs'))
 main=MAIN.replace('LATENCY_MODULE',module).replace('VARIANT_VALUE',variant)
 if variant=='qmdb' and (ROOT/'candidate/latency_disk.rs').exists():
  for name in ['latency_disk.rs','disk_fixture.rs']:shutil.copy2(ROOT/'candidate'/name,dst/name)
  main=main.replace('mod latency_candidate;','mod latency_candidate;\nmod latency_disk;\nmod disk_fixture;')
  main=main.replace('else {latency_candidate::run(&mode,samples,warmup);}', 'else if mode.starts_with("disk-receive-") {latency_disk::run(&mode,samples,warmup);} else {latency_candidate::run(&mode,samples,warmup);}')
 (dst/'bench.rs').write_text(main)
 cargo=package/'Cargo.toml';s=cargo.read_text();marker='\n# Scratch matched latency target\n'
 if marker in s:s=s[:s.index(marker)]
 s+=marker+'[[bench]]\nname = "bajillion_latency"\nharness = false\npath = "src/bajillion/benches_latency/bench.rs"\n';cargo.write_text(s)
 return dst

def main():
 p=argparse.ArgumentParser();p.add_argument('--reference',type=pathlib.Path,required=True);p.add_argument('--candidate',type=pathlib.Path,required=True);p.add_argument('--variant',choices=['reference','qmdb'],action='append');p.add_argument('--jobs',type=int,default=8);p.add_argument('--candidate-patch',type=pathlib.Path,help='Record an already-applied patch against the pinned candidate; verify reverse applicability');p.add_argument('--install-only',action='store_true');a=p.parse_args()
 (ROOT/'bin').mkdir(exist_ok=True);(ROOT/'build-logs').mkdir(exist_ok=True)
 for variant,source in [('reference',a.reference.resolve()),('qmdb',a.candidate.resolve())]:
  if a.variant and variant not in a.variant:continue
  patch=None
  if variant=='qmdb' and a.candidate_patch:
   patch=a.candidate_patch.resolve()
   subprocess.run(['git','apply','--reverse','--check',str(patch)],cwd=source,check=True)
  dst=install(source,variant)
  features='bench,arbitrary,commonware-runtime/test-utils' if variant=='qmdb' and (ROOT/'candidate/latency_disk.rs').exists() else ('bench,arbitrary' if variant=='qmdb' else 'arbitrary')
  cmd=['cargo','bench','--locked','-p','commonware-clearing','--bench','bajillion_latency','--features',features,'--no-run','--message-format=json']
  env=os.environ.copy();env['RUSTFLAGS']='--cfg full_bench';env['CARGO_BUILD_JOBS']=str(a.jobs);env['CARGO_TARGET_DIR']=str(source/'target')
  manifest={'variant':variant,'source_revision':PINS[variant],'command':cmd,'cwd':str(source),'environment':{'RUSTFLAGS':env['RUSTFLAGS'],'CARGO_BUILD_JOBS':env['CARGO_BUILD_JOBS'],'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']},'rustc':subprocess.check_output(['rustc','-vV'],text=True),'overlay_sha256':{str(x.relative_to(dst)):sha(x) for x in sorted(dst.rglob('*.rs'))},'lock_sha256':sha(source/'Cargo.lock'),'source_sha256':source_hashes(source)}
  archive=source.parent/('qmdb-source.tar.gz' if variant=='qmdb' else 'reference-source.tar.gz')
  if patch:manifest['source_patch']={'path':str(patch),'sha256':sha(patch),'base_revision':PINS[variant],'application_checked':'git apply --reverse --check'}
  if archive.exists():manifest['source_archive']={'path':str(archive),'sha256':sha(archive),'revision':PINS[variant],'export_verification_owner':'root'}
  if a.install_only:print(json.dumps(manifest));continue
  with (ROOT/'build-logs'/f'{variant}.jsonl').open('w') as out,(ROOT/'build-logs'/f'{variant}.log').open('w') as err:r=subprocess.run(cmd,cwd=source,env=env,stdout=out,stderr=err)
  if r.returncode:raise SystemExit(f'{variant} build failed: build-logs/{variant}.log')
  messages=[json.loads(x) for x in (ROOT/'build-logs'/f'{variant}.jsonl').read_text().splitlines() if x.startswith('{')]
  binaries=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('target',{}).get('name')=='bajillion_latency' and m.get('executable')]
  assert len(binaries)==1,binaries
  binary=ROOT/'bin'/variant;shutil.copy2(binaries[0],binary);manifest['binary_sha256']=sha(binary)
  (ROOT/'bin'/f'{variant}.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'variant':variant,'binary':str(binary),'sha256':manifest['binary_sha256']}),flush=True)
if __name__=='__main__':main()
