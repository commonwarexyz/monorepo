use super::fixtures::{self, ActiveProfile, OPENING_BALANCE};
use bytes::Bytes;
use commonware_clearing::bajillion::{
    boundary::{DepositBatch, SignedWithdrawal, WithdrawalAction, WithdrawalBatch},
    qmdb::{State, account_key},
    transition::{CloseContext, CloseLimits, EpochContext},
};
use commonware_cryptography::{Hasher as _, Sha256, Signer as _, sha256::Digest};
use commonware_cryptography_curve25519::signing::{SigningKey, StrictVerifyingKey as Key};
use commonware_parallel::Rayon;
use commonware_runtime::{
    tokio,
    utils::buffer::paged::{CacheRef, page_size},
};
use commonware_utils::NZUsize;
use std::num::NonZeroU64;

pub(crate) type DiskState = State<tokio::Context, Sha256, Rayon>;
pub(crate) const PHYSICAL_PAGE_SIZE: u32 = 4096;

pub(crate) struct DiskOwner {
    pub(crate) state: DiskState,
    pub(crate) cache: CacheRef,
}

pub(crate) const SMOKE_PROFILE: ActiveProfile = ActiveProfile {
    live_accounts: 64,
    senders: 64,
    credited_accounts: 8,
    out_degree: 1,
};
pub(crate) const SMOKE_WITHDRAWALS: usize = 4;

fn deployment() -> Digest {
    Sha256::hash(&[b"clearing-benchmark-deployment"])
}

/// Opens the native partitions with a fresh application page cache.
pub(crate) async fn reopen(runtime: tokio::Context, prefix: &str) -> DiskOwner {
    let mut config = fixtures::state_config(&runtime, prefix);
    let cache = CacheRef::from_pooler(&runtime, page_size(PHYSICAL_PAGE_SIZE), NZUsize!(1024));
    config.journal_config.page_cache = cache.clone();
    config.merkle_config.page_cache = cache.clone();
    let state = State::open(runtime, config).await.expect("open disk state");
    DiskOwner { state, cache }
}

/// Installs and durably commits the same funded genesis used by the native fixtures.
pub(crate) async fn initialize(
    runtime: tokio::Context,
    accounts: &[(Key, SigningKey)],
    prefix: &str,
) -> DiskOwner {
    let DiskOwner { state, cache } = reopen(runtime, prefix).await;
    assert!(
        state.is_bootstrap(),
        "initialization requires fresh partitions"
    );
    let genesis = accounts
        .iter()
        .map(|(key, _)| {
            (
                account_key(key).expect("canonical account key"),
                NonZeroU64::new(OPENING_BALANCE),
            )
        })
        .collect();
    let prepared = state
        .prepare(state.head(), genesis)
        .await
        .expect("prepare canonical genesis");
    let state = state
        .apply(prepared)
        .await
        .expect("apply canonical genesis")
        .commit()
        .await
        .expect("commit canonical genesis");
    DiskOwner { state, cache }
}

pub(crate) async fn epoch_context(
    state: &DiskState,
    epoch: u64,
    committee: Digest,
    operator: &SigningKey,
    deposits: &DepositBatch<Key>,
    withdrawals: &WithdrawalBatch<Key, Digest>,
) -> CloseContext<Key, Digest> {
    EpochContext::new::<Sha256>(
        deployment(),
        epoch,
        operator.public_key(),
        deposits,
        withdrawals,
        state.liability(),
        98,
        99,
        CloseLimits::protocol_maximum(),
        committee,
    )
    .expect("epoch context")
    .bind::<Sha256, _, _>(state, deposits, withdrawals)
    .await
    .expect("bound disk context")
}

/// Signs amount-one requests from the first funded accounts against the current predecessor.
pub(crate) fn withdrawals(
    state: &DiskState,
    accounts: &[(Key, SigningKey)],
    count: usize,
) -> WithdrawalBatch<Key, Digest> {
    assert!(
        count <= accounts.len(),
        "withdrawal accounts are funded genesis accounts"
    );
    WithdrawalBatch::new(
        accounts[..count]
            .iter()
            .map(|(_, signer)| {
                SignedWithdrawal::sign(
                    deployment(),
                    state.root().digest,
                    Bytes::from_static(b"disk-latency-destination"),
                    WithdrawalAction::Amount(NonZeroU64::MIN),
                    u64::MAX,
                    signer,
                )
            })
            .collect(),
    )
    .expect("canonical funded withdrawals")
}
