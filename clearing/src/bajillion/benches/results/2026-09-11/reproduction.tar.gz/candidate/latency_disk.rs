use super::{admission_fixtures::Validators, disk_fixture, fixtures};
use bytes::BytesMut;
use commonware_clearing::bajillion::{
    boundary::DepositBatch,
    posted,
    qmdb::account_key,
    transition::{prepare_close_with_strategy, validate_close_with_strategy},
};
use commonware_codec::Write as _;
use commonware_cryptography::{
    Hasher as _, Sha256, Signer as _,
    bls12381::primitives::{
        group::{Private, Scalar},
        ops::compute_public,
        variant::MinSig,
    },
};
use commonware_cryptography_curve25519::signing::{BatchVerifier, SigningKey};
use commonware_runtime::{Metrics as _, Runner as _, Supervisor as _, tokio};
use commonware_utils::{Participant, TestRng};
use std::{collections::BTreeMap, fmt::Write as _, hint::black_box, path::PathBuf, time::Instant};

const COUNTERS: [&str; 5] = [
    "get_calls_total",
    "get_many_calls_total",
    "lookups_requested_total",
    "storage_reads_total",
    "storage_read_bytes_total",
];

fn json_string(value: &str) -> String {
    let mut encoded = String::from("\"");
    for character in value.chars() {
        match character {
            '"' => encoded.push_str("\\\""),
            '\\' => encoded.push_str("\\\\"),
            c if c <= '\u{1f}' => write!(encoded, "\\u{:04x}", c as u32).unwrap(),
            c => encoded.push(c),
        }
    }
    encoded.push('"');
    encoded
}

fn counter_kind(series: &str) -> Option<usize> {
    let name = series.split('{').next().unwrap();
    COUNTERS.iter().position(|suffix| name.ends_with(suffix))
}

struct Snapshot {
    text: String,
    values: BTreeMap<String, u64>,
}

fn snapshot(runtime: &tokio::Context) -> Snapshot {
    let mut values = BTreeMap::new();
    for line in runtime
        .encode()
        .lines()
        .filter(|line| !line.starts_with('#'))
    {
        let Some((series, value)) = line.rsplit_once(' ') else {
            continue;
        };
        if counter_kind(series).is_some() {
            values.insert(
                series.to_owned(),
                value.parse::<u64>().expect("integer native counter"),
            );
        }
    }
    assert!(
        COUNTERS.iter().all(|suffix| values.keys().any(|key| key
            .split('{')
            .next()
            .unwrap()
            .ends_with(suffix))),
        "native counters must be registered"
    );
    let text = values
        .iter()
        .map(|(key, value)| format!("{key} {value}\n"))
        .collect();
    Snapshot { text, values }
}

fn emit_metrics(mode: &str, step: usize, warmup: usize, before: Snapshot, after: Snapshot) {
    let mut totals = [0u64; 5];
    let mut deltas = Vec::new();
    for (series, value) in after.values {
        let delta = value
            .checked_sub(before.values.get(&series).copied().unwrap_or(0))
            .expect("monotonic native counter");
        totals[counter_kind(&series).unwrap()] += delta;
        deltas.push(format!("{}:{delta}", json_string(&series)));
    }
    println!(
        "{{\"record\":\"disk_metrics\",\"variant\":\"qmdb\",\"mode\":\"{mode}\",\"sample\":{step},\"epoch\":{},\"warmup\":{},\"scalar_get_calls\":{},\"batch_get_calls\":{},\"lookups_requested\":{},\"storage_reads\":{},\"storage_read_bytes\":{},\"metrics_before\":{},\"metrics_after\":{},\"counter_deltas\":{{{}}}}}",
        fixtures::EPOCH + step as u64,
        step < warmup,
        totals[0],
        totals[1],
        totals[2],
        totals[3],
        totals[4],
        json_string(&before.text),
        json_string(&after.text),
        deltas.join(",")
    );
}

pub(crate) fn run(mode: &str, samples: usize, warmup: usize) {
    assert!(matches!(
        mode,
        "disk-receive-steady" | "disk-receive-first-touch"
    ));
    let smoke = std::env::var("COMMONWARE_LATENCY_SMOKE").is_ok_and(|value| value == "1");
    assert!(
        samples >= 10 || smoke,
        "published disk runs require at least ten samples"
    );
    let profile = if smoke {
        disk_fixture::SMOKE_PROFILE
    } else {
        fixtures::latency_profile()
    };
    let withdrawals_count = std::env::var("COMMONWARE_LATENCY_WITHDRAWALS")
        .map(|value| value.parse::<usize>().expect("withdrawal count"))
        .unwrap_or(if smoke {
            disk_fixture::SMOKE_WITHDRAWALS
        } else {
            0
        });
    assert!(withdrawals_count <= profile.live_accounts);
    let directory = PathBuf::from(
        std::env::var_os("COMMONWARE_LATENCY_DISK_DIRECTORY")
            .expect("explicit disk directory required"),
    );
    std::fs::create_dir_all(&directory).expect("create disk directory");
    assert!(
        std::fs::read_dir(&directory)
            .expect("read disk directory")
            .next()
            .is_none(),
        "each run requires an empty disk directory"
    );
    let first_touch = mode == "disk-receive-first-touch";
    let physical_page_bytes = disk_fixture::PHYSICAL_PAGE_SIZE;
    let logical_page_bytes =
        commonware_runtime::utils::buffer::paged::page_size(physical_page_bytes).get();
    println!(
        "{{\"record\":\"disk_metadata\",\"variant\":\"qmdb\",\"mode\":\"{mode}\",\"N\":{},\"A\":{},\"R\":{},\"K\":{},\"W\":{withdrawals_count},\"workers\":16,\"validators\":100,\"runtime\":\"tokio\",\"runtime_workers\":2,\"max_blocking_threads\":512,\"storage_directory\":{},\"logical_page_bytes\":{logical_page_bytes},\"physical_page_bytes\":{physical_page_bytes},\"cache_pages\":1024,\"native_cache_cleared\":{first_touch},\"os_cache\":\"uncontrolled\",\"smoke\":{smoke},\"durability_boundary\":\"native_State_commit\"}}",
        profile.live_accounts,
        profile.senders,
        profile.credited_accounts,
        profile.out_degree,
        json_string(&directory.to_string_lossy())
    );
    tokio::Runner::new(tokio::Config::new().with_storage_directory(directory).with_worker_threads(2).with_max_blocking_threads(512)).start(|runtime| async move {
        let accounts = fixtures::accounts(profile.live_accounts);
        let seeded_producer = disk_fixture::initialize(runtime.child("producer_seed"), &accounts, "producer").await;
        let seeded_receiver = disk_fixture::initialize(runtime.child("receiver_seed"), &accounts, "receiver").await;
        let genesis = *seeded_producer.state.head();
        assert_eq!(seeded_receiver.state.head(), &genesis);
        drop(seeded_producer);
        drop(seeded_receiver);
        let mut producer = disk_fixture::reopen(runtime.child("producer"), "producer").await;
        let mut receiver = disk_fixture::reopen(runtime.child("receiver_open"), "receiver").await;
        assert_eq!(producer.state.head(), &genesis);
        assert_eq!(receiver.state.head(), &genesis);
        let operator = SigningKey::from_seed(1);
        let operator_bls = compute_public::<MinSig>(&Private::new(Scalar::from(1u64)));
        let validators = Validators::new();
        let committee = validators.committee().commitment::<Sha256>();
        let signer = validators.signer(Participant::new(0));
        let deposits = DepositBatch::empty();
        for step in 0..samples + warmup {
            let withdrawals = disk_fixture::withdrawals(&producer.state, &accounts, withdrawals_count);
            let context = disk_fixture::epoch_context(&producer.state, fixtures::EPOCH + step as u64, committee, &operator, &deposits, &withdrawals).await;
            let (terminals, acks) = fixtures::terminal_material(profile, &accounts, &context, &operator);
            drop(acks);
            let prepared = prepare_close_with_strategy::<Sha256, _, _, _, _>(&producer.state, &context, &deposits, &withdrawals, terminals, fixtures::strategy()).await.expect("producer prepare");
            let wire = prepared.encoded().clone();
            let (advanced, close) = prepared.apply(producer.state).await.expect("producer apply");
            producer.state = advanced.commit().await.expect("producer commit outside receive timer");
            drop(close);

            if first_touch {
                // The previous receive (or genesis) is committed. Reopen rebuilds native state;
                // clearing its actual page cache happens only after all initialization reads finish.
                let head = *receiver.state.head();
                drop(receiver);
                receiver = disk_fixture::reopen(runtime.child("receiver_sample").with_attribute("sample", step), "receiver").await;
                assert_eq!(receiver.state.head(), &head);
                receiver.cache.clear();
            }
            let mut rng = TestRng::new(step as u64);
            let before = snapshot(&runtime);
            let start = Instant::now();
            let decode_start = Instant::now();
            let dealing = posted::decode(wire, &context).expect("decode received packet");
            let decode_elapsed = decode_start.elapsed();
            let validate_start = Instant::now();
            assert!(signer.me().is_some());
            assert_eq!(signer.committee().commitment::<Sha256>(), *context.committee());
            let prepared = validate_close_with_strategy::<Sha256, _, _, _, _, BatchVerifier, _>(&receiver.state, &context, &operator_bls, &deposits, &withdrawals, dealing, &mut rng, fixtures::strategy()).await.expect("public full validation");
            let validate_elapsed = validate_start.elapsed();
            let vote_start = Instant::now();
            let vote = signer.sign(&prepared.close().header).expect("sign verified close");
            let vote_elapsed = vote_start.elapsed();
            let apply_start = Instant::now();
            let (advanced, close) = prepared.apply(receiver.state).await.expect("receiver apply");
            let apply_elapsed = apply_start.elapsed();
            let commit_start = Instant::now();
            receiver.state = advanced.commit().await.expect("receiver native commit");
            let commit_elapsed = commit_start.elapsed();
            let elapsed = start.elapsed();
            let after = snapshot(&runtime);

            assert_eq!(receiver.state.head(), producer.state.head());
            assert_eq!(receiver.state.liability(), profile.live_accounts as u64 * fixtures::OPENING_BALANCE - (step + 1) as u64 * withdrawals_count as u64);
            black_box((&vote, &close));
            emit_metrics(mode, step, warmup, before, after);
            println!("{{\"record\":\"disk_correctness\",\"variant\":\"qmdb\",\"mode\":\"{mode}\",\"sample\":{step},\"epoch\":{},\"warmup\":{},\"status\":\"ok\",\"root\":\"{}\",\"operations\":{}}}", fixtures::EPOCH + step as u64, step < warmup, receiver.state.root().digest, receiver.state.head().operations());
            if !smoke {
                for (phase, duration) in [("decode", decode_elapsed), ("validate-decoded", validate_elapsed), ("vote", vote_elapsed), ("apply", apply_elapsed), ("commit", commit_elapsed)] {
                    crate::emit_phase(mode, phase, step, warmup, duration);
                }
                crate::emit_sample(mode, step, warmup, elapsed);
            }
        }
        let head = *receiver.state.head();
        drop(receiver);
        let receiver = disk_fixture::reopen(runtime.child("receiver_final"), "receiver").await;
        assert_eq!(receiver.state.head(), &head);
        let epochs = samples + warmup;
        let mut credits = vec![0u64; profile.credited_accounts];
        for sender in 0..profile.senders {
            for offset in 0..profile.out_degree { credits[(sender + offset) % profile.credited_accounts] += 1; }
        }
        let mut fingerprint = BytesMut::new();
        (accounts.len() as u64).write(&mut fingerprint);
        for (chunk_index, chunk) in accounts.chunks(4096).enumerate() {
            let keys = chunk.iter().map(|(key, _)| account_key(key).unwrap()).collect::<Vec<_>>();
            let references = keys.iter().collect::<Vec<_>>();
            let actual = receiver.state.get_many(&references).await.expect("final reopened balances");
            for (offset, ((account, _), balance)) in chunk.iter().zip(actual).enumerate() {
                let index = chunk_index * 4096 + offset;
                let credit = credits.get(index).copied().unwrap_or(0);
                let debit = if index < profile.senders { profile.out_degree as u64 } else { 0 };
                let withdrawn = u64::from(index < withdrawals_count);
                let expected = fixtures::OPENING_BALANCE + epochs as u64 * credit - epochs as u64 * (debit + withdrawn);
                let actual = balance.expect("funded account remains present").get();
                assert_eq!(actual, expected);
                account.write(&mut fingerprint);
                actual.write(&mut fingerprint);
            }
        }
        println!("{{\"record\":\"oracle\",\"variant\":\"qmdb\",\"mode\":\"{mode}\",\"completed_epochs\":{epochs},\"logical_state_sha256\":\"{}\",\"operations\":{},\"reopened\":true,\"W\":{withdrawals_count}}}", Sha256::hash(&[&fingerprint]), receiver.state.head().operations());
    });
}
