use super::{
    admission_fixtures::{VALIDATORS, Validators},
    fixtures::{self, BenchState},
};
use bytes::BytesMut;
use commonware_clearing::bajillion::{
    admission::seal,
    boundary::{DepositBatch, WithdrawalBatch},
    posted,
    qmdb::account_key,
    transition::{prepare_close_with_strategy, validate_close_with_strategy},
};
use commonware_codec::Write as _;
use commonware_cryptography::{
    Hasher as _, Sha256, Signer as _,
    bls12381::primitives::{
        group::{Private, Scalar},
        ops::compute_public,
        variant::MinSig,
    },
};
use commonware_cryptography_curve25519::signing::{BatchVerifier, SigningKey, StrictVerifyingKey};
use commonware_runtime::{Runner as _, Supervisor as _, deterministic};
use commonware_utils::{Participant, TestRng};
use std::{hint::black_box, num::NonZeroU64, time::Instant};

async fn initialize(
    runtime: deterministic::Context,
    accounts: &[(StrictVerifyingKey, SigningKey)],
    prefix: &str,
) -> BenchState {
    let config = fixtures::state_config(&runtime, prefix);
    let state = BenchState::open(runtime, config)
        .await
        .expect("native open");
    assert!(state.is_bootstrap());
    let genesis = accounts
        .iter()
        .map(|(key, _)| {
            (
                account_key(key).unwrap(),
                NonZeroU64::new(fixtures::OPENING_BALANCE),
            )
        })
        .collect();
    let prepared = state
        .prepare(state.head(), genesis)
        .await
        .expect("genesis prepare");
    state.apply(prepared).await.expect("genesis apply")
}

pub(crate) fn run(mode: &str, samples: usize, warmup: usize) {
    if mode == "sign-vote" {
        let fixture = super::admission_fixtures::certificate_fixture();
        let signer = Validators::new().signer(Participant::new(0));
        for step in 0..samples + warmup {
            let start = Instant::now();
            let vote = signer.sign(&fixture.header).expect("sign");
            let elapsed = start.elapsed();
            black_box(vote);
            crate::emit_sample(mode, step, warmup, elapsed);
        }
        return;
    }
    assert!(matches!(
        mode,
        "prepare-apply"
            | "receive-apply"
            | "receive-phases"
            | "seal-decode"
            | "seal-predecoded"
            | "balance-fetch"
    ));
    let profile = fixtures::latency_profile();
    fixtures::runner().start(|runtime| async move {
        let accounts=fixtures::accounts(profile.live_accounts);
        let mut producer=initialize(runtime.child("producer"),&accounts,"producer").await;
        if mode=="balance-fetch" {
            let activity=profile.senders.max(profile.credited_accounts.min(profile.senders+profile.out_degree-1));
            let keys=accounts[..activity].iter().map(|(key,_)|account_key(key).unwrap()).collect::<Vec<_>>();
            let refs=keys.iter().collect::<Vec<_>>();
            for step in 0..samples+warmup {
                let start=Instant::now();
                let balances=producer.get_many(&refs).await.expect("activity balances");
                let elapsed=start.elapsed();
                assert_eq!(balances.len(),activity);
                assert!(balances.iter().all(|v|v.map(NonZeroU64::get)==Some(fixtures::OPENING_BALANCE)));
                black_box(&balances);
                crate::emit_sample(mode,step,warmup,elapsed);
            }
            return;
        }
        let mut receiver=if mode=="prepare-apply" {None} else {Some(initialize(runtime.child("receiver"),&accounts,"receiver").await)};
        let operator=SigningKey::from_seed(1);
        let operator_bls=compute_public::<MinSig>(&Private::new(Scalar::from(1u64)));
        let validators=Validators::new();
        let committee=validators.committee().commitment::<Sha256>();
        let signer=validators.signer(Participant::new(0));
        let deposits=DepositBatch::empty();
        let withdrawals=WithdrawalBatch::empty();
        let mut first=None;
        for step in 0..samples+warmup {
            let epoch=fixtures::EPOCH+if mode.starts_with("seal") {0} else {step as u64};
            let context=fixtures::epoch_context(&producer,epoch,committee,&operator,&deposits,&withdrawals).await;
            let (terminals,acks)=fixtures::terminal_material(profile,&accounts,&context,&operator);
            drop(acks);
            if mode=="prepare-apply" {
                let start=Instant::now();
                let prepared=prepare_close_with_strategy::<Sha256,_,_,_,_>(&producer,&context,&deposits,&withdrawals,terminals,fixtures::strategy()).await.expect("prepare");
                let packets=(0..VALIDATORS).map(|_|prepared.encoded().clone()).collect::<Vec<_>>();
                let (advanced,close)=prepared.apply(producer).await.expect("apply");
                let elapsed=start.elapsed();
                producer=advanced;
                assert_eq!(producer.root(),close.roots.successor);
                assert_eq!(producer.liability(),profile.live_accounts as u64*fixtures::OPENING_BALANCE);
                if first.is_none(){first=Some(*producer.head());}
                black_box((&close,&packets));
                crate::emit_sample(mode,step,warmup,elapsed);
            } else {
                let prepared=prepare_close_with_strategy::<Sha256,_,_,_,_>(&producer,&context,&deposits,&withdrawals,terminals,fixtures::strategy()).await.expect("producer prepare");
                let wire=prepared.encoded().clone();
                if matches!(mode,"receive-apply"|"receive-phases") {
                    let (advanced,close)=prepared.apply(producer).await.expect("producer apply outside receive timer");
                    producer=advanced;
                    drop(close);
                } else {drop(prepared);}
                let state=receiver.take().unwrap();
                let mut rng=TestRng::new(step as u64);
                let decoded=if mode=="seal-predecoded" {Some(posted::decode(wire.clone(),&context).expect("decode outside seal"))}else{None};
                let mut phases=None;
                let start=Instant::now();
                let (vote,prepared)=if matches!(mode,"receive-phases"|"seal-predecoded") {
                    let decode_start=Instant::now();
                    let dealing=decoded.unwrap_or_else(||posted::decode(wire,&context).expect("decode"));
                    let decode_elapsed=decode_start.elapsed();
                    let verify_start=Instant::now();
                    assert!(signer.me().is_some());
                    assert_eq!(signer.committee().commitment::<Sha256>(),*context.committee());
                    let validate_start=Instant::now();
                    let prepared=validate_close_with_strategy::<Sha256,_,_,_,_,BatchVerifier,_>(&state,&context,&operator_bls,&deposits,&withdrawals,dealing,&mut rng,fixtures::strategy()).await.expect("full decoded validation");
                    let validate_elapsed=validate_start.elapsed();
                    let vote_start=Instant::now();
                    let vote=signer.sign(&prepared.close().header).expect("vote");
                    let vote_elapsed=vote_start.elapsed();
                    let verify_elapsed=verify_start.elapsed();
                    phases=Some([("decode",decode_elapsed),("verify-and-vote",verify_elapsed),("validate-decoded",validate_elapsed),("vote",vote_elapsed)]);
                    (vote,prepared)
                }else{
                    seal::<Sha256,_,_,_,_,BatchVerifier,_>(&signer,&state,&context,&operator_bls,&deposits,&withdrawals,wire,&mut rng,fixtures::strategy()).await.expect("receive seal")
                };
                if matches!(mode,"receive-apply"|"receive-phases") {
                    let apply_start=Instant::now();
                    let (advanced,close)=prepared.apply(state).await.expect("receiver apply");
                    let apply_elapsed=apply_start.elapsed();
                    let elapsed=start.elapsed();

                    assert_eq!(advanced.root(),producer.root());
                    if first.is_none(){first=Some(*advanced.head());}
                    black_box((&vote,&close));
                    receiver=Some(advanced);
                    crate::emit_sample(mode,step,warmup,elapsed);
                    if mode=="receive-phases" {for (phase,duration) in phases.unwrap() {crate::emit_phase(mode,phase,step,warmup,duration);} crate::emit_phase(mode,"apply",step,warmup,apply_elapsed);}
                } else {
                    let elapsed=start.elapsed();
                    assert_eq!(prepared.state().predecessor().root(),state.root());
                    black_box((&vote,&prepared));
                    receiver=Some(state);
                    crate::emit_sample(mode,step,warmup,elapsed);
                }
            }
        }
        let state=receiver.as_ref().unwrap_or(&producer);
        if let Some(head)=first {
            let key=account_key(&accounts[0].0).unwrap();
            let opening=state.lookup_at(head.root(),head.operations(),&key).await.expect("retained first prefix");
            assert!(opening.resolve::<Sha256>(&head.root(),&key).unwrap().is_some());
        }
        let epochs=if mode.starts_with("seal"){0}else{samples+warmup};
        let mut counts=vec![0u64;profile.credited_accounts];
        for sender in 0..profile.senders {for offset in 0..profile.out_degree {counts[(sender+offset)%profile.credited_accounts]+=1;}}
        let mut fingerprint=BytesMut::new();
        (accounts.len() as u64).write(&mut fingerprint);
        for (i,(account,_)) in accounts.iter().enumerate(){
            let actual=state.get(&account_key(account).unwrap()).await.unwrap().unwrap().get();
            let credit=counts.get(i).copied().unwrap_or(0);
            let debit=if i<profile.senders {profile.out_degree as u64}else{0};
            let expected=fixtures::OPENING_BALANCE+epochs as u64*credit-epochs as u64*debit;
            assert_eq!(actual,expected);
            account.write(&mut fingerprint);actual.write(&mut fingerprint);
        }
        println!("{{\"record\":\"oracle\",\"variant\":\"qmdb\",\"mode\":\"{mode}\",\"completed_epochs\":{epochs},\"logical_state_sha256\":\"{}\",\"operations\":{}}}",Sha256::hash(&[&fingerprint]),state.head().operations());
    });
}
