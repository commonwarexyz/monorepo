#!/usr/bin/env python3
"""Summarize completed raw timing results without combining distinct cost boundaries."""
import argparse,json,pathlib,statistics

def main():
    p=argparse.ArgumentParser();p.add_argument('runs',type=pathlib.Path,nargs='+');p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
    rows=[]
    for root in a.runs:
        for path in sorted(root.glob('*/run.json')):
            r=json.loads(path.read_text())
            if r.get('validation')!='passed':continue
            t=r['task'];base={'profile':t['profile'],'variant':t['variant'],'mode':t['mode'],'run':str(path),'wall_seconds':r['wall_seconds'],'peak_observed_rss_bytes':r['peak_observed_rss_bytes']}
            if 'disk_metadata' in r:
                base.update(storage=r['disk_metadata'],counter_scope=r['counter_scope'],raw_receive_counters=[m for m in r['disk_metrics'] if not m['warmup']])
            if 'timing_ns' in r:
                values=r['timing_ns']['samples'];row=base|{'samples':len(values),'median_ns':statistics.median(values),'min_ns':min(values),'max_ns':max(values),'raw_ns':values}
                if len(values)>=2:
                    q=statistics.quantiles(values,n=4,method='inclusive');row.update(q1_ns=q[0],q3_ns=q[2])
                rows.append(row)
            for name,values in r.get('phase_timings_ns',{}).items():
                rows.append(base|{'phase':name,'samples':len(values),'median_ns':statistics.median(values),'min_ns':min(values),'max_ns':max(values),'raw_ns':values,'nested_scope':t['mode']=='receive-phases' and t['variant']=='qmdb' and name in ('validate-decoded','vote')})
            for sample in sorted(path.parent.glob('criterion/**/new/sample.json')):
                raw=json.loads(sample.read_text());values=[ns/iters for ns,iters in zip(raw['times'],raw['iters'])]
                benchmark=sample.with_name('benchmark.json');estimates=sample.with_name('estimates.json')
                label=json.loads(benchmark.read_text()) if benchmark.exists() else {'path':str(sample.parent)}
                full_id=label.get('full_id','')
                encoded=[];size_context=[]
                if '::artifact_latency::' in full_id:
                    operation,labels=full_id.split('::artifact_latency::',1)[1].split('/',1)
                    fields=dict(part.split('=',1) for part in labels.split())
                    size_context=[item for item in r.get('artifact_sizes',[]) if item.get('artifact')==operation.split('::')[0] and all(item.get(k)==v for k,v in fields.items())]
                    encoded=[item['bytes'] for item in size_context]
                    assert len(encoded)==1, f'missing/ambiguous encoded size for {full_id}'
                rows.append(base|{'encoded_bytes':encoded[0] if encoded else None,'size_context':size_context,'benchmark':label,'samples':len(values),'median_ns':statistics.median(values),'raw_ns_per_iteration':values,'estimates':json.loads(estimates.read_text()) if estimates.exists() else None,'raw_sample':str(sample)})
    a.output.mkdir(parents=True,exist_ok=False)
    (a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    lines=['# External benchmark observations','','Rows contain directly timed complete operations and named phases. Receive/application samples advance successive epochs; seal and balance-lookup probes reuse a fixed predecessor. Candidate validate-decoded and vote are nested within verify-and-vote and must not be summed with it. Criterion artifact samples repeat immutable-artifact verification. Native predecoded boundaries differ in resident expansion and state reads; do not infer components by subtraction.','', '| Variant | N | A | R | K | Operation | Median (ms) | Samples |','|---|---:|---:|---:|---:|---|---:|---:|']
    for r in rows:
        p=r['profile'];op=r.get('benchmark',{}).get('full_id',r['mode']+('::'+r['phase'] if 'phase' in r else ''));lines.append(f"| {r['variant']} | {p['N']} | {p['A']} | {p['R']} | {p['K']} | {op} | {r['median_ns']/1e6:.6f} | {r['samples']} |")
    (a.output/'TABLES.md').write_text('\n'.join(lines)+'\n')
if __name__=='__main__':main()
