//! Fixed-length consecutive closes against reference 3a3b934662d1d590ea553b8734d241041b6b8182.

use super::{
    admission_fixtures::{VALIDATORS, Validators},
    fixtures::{ActiveProfile, latency_profile, strategy},
};
use bytes::{Bytes, BytesMut};
use commonware_clearing::bajillion::{
    admission::{SealedDealing, Vote, bls12381, seal},
    boundary::{DepositBatch, WithdrawalBatch},
    payment::{SendAuthorization, VECTOR_ACK_AGGREGATE_NAMESPACE, VectorAck, VectorSendBody},
    retained::{Interval, Wire, decode_dealt_slice_bounded},
    state::{AccountRow, AccountState, Prefix, SettlementOutput, StateLeaf},
    transition::{
        CloseContext, CloseLimits, EpochContext, Header, OperatorKey, OperatorSignature,
        OperatorVariant, PreparedClose, ProofSlice, RootBundle, StateCache, account_slice,
        prepare_close_with_strategy,
    },
    vector::{OutEntry, OutVector, TransposeEntry},
};
use commonware_codec::{Encode as _, EncodeSize as _, ReadExt as _, Write as _};
use commonware_cryptography::{
    Hasher as _, Sha256, Signer as _,
    bls12381::primitives::{
        group::{Private, Scalar},
        ops::{compute_public, sign_message},
    },
    lthash::LtHash,
    sha256::Digest,
};
use commonware_cryptography_curve25519::signing::{
    BatchVerifier as PaymentBatchVerifier, SigningKey, StrictVerifyingKey as Key,
};
use commonware_parallel::Strategy as _;
use commonware_utils::{Participant, TestRng};
use std::{hint::black_box, ops::Range, time::Instant};

const FIRST_EPOCH: u64 = 7;
const OPENING_BALANCE: u64 = 1_000_000;
const ACCOUNT_SEED_START: u64 = 10_000;
const OPERATOR_SEED: u64 = 1;

type Cache = StateCache<Key, Digest>;
type Context = CloseContext<Key, Digest>;
type Prepared = PreparedClose<Key, Digest>;

struct Terminal {
    vector: OutVector<Key>,
    authorization: SendAuthorization<Key, Digest>,
    operator_signature: OperatorSignature,
}

struct Terminals {
    items: Vec<Terminal>,
    partials: Vec<LtHash>,
}

struct Packet {
    envelope: Bytes,
    slices: Vec<Wire>,
}

impl Packet {
    fn size(&self) -> usize {
        self.envelope.len()
            + self
                .slices
                .iter()
                .map(|slice| slice.encode_size())
                .sum::<usize>()
    }
}

struct Produced {
    prepared: Prepared,
    packets: Vec<Packet>,
}

struct Source {
    profile: ActiveProfile,
    cache: Cache,
    payers: Vec<(Key, SigningKey)>,
    recipients: Vec<Key>,
    oracle_credits: Vec<u64>,
    operator: SigningKey,
    operator_private: Private,
    operator_bls: OperatorKey,
    validators: Validators,
    spans: Vec<Vec<Range<u16>>>,
    distinct: Vec<Range<u16>>,
    deposits: DepositBatch<Key>,
    withdrawals: WithdrawalBatch<Key, Digest>,
}

impl Source {
    fn new(profile: ActiveProfile) -> Self {
        assert!(profile.live_accounts > 0 && profile.live_accounts <= u32::MAX as usize);
        assert!(profile.senders > 0 && profile.senders <= profile.live_accounts);
        assert!(
            profile.credited_accounts > 0 && profile.credited_accounts <= profile.live_accounts
        );
        assert!(profile.out_degree > 0 && profile.out_degree <= profile.credited_accounts);
        assert!(profile.senders.checked_mul(profile.out_degree).unwrap() <= u32::MAX as usize);
        let mut accounts = (0..profile.live_accounts)
            .map(|index| {
                let private =
                    SigningKey::from_seed(ACCOUNT_SEED_START + u64::try_from(index).unwrap());
                (private.public_key(), private)
            })
            .collect::<Vec<_>>();
        accounts.sort_unstable_by(|left, right| left.0.cmp(&right.0));
        let cache = Cache::new_with_strategy::<Sha256>(
            accounts
                .iter()
                .map(|(public, _)| StateLeaf {
                    account: public.clone(),
                    state: AccountState {
                        balance: OPENING_BALANCE,
                        active: true,
                        ..AccountState::default()
                    },
                })
                .collect(),
            strategy(),
        )
        .expect("reference genesis");
        let recipients = accounts[..profile.credited_accounts]
            .iter()
            .map(|(key, _)| key.clone())
            .collect();
        // This independent oracle is never used to construct terminal or close material.
        let mut oracle_credits = vec![0_u64; profile.credited_accounts];
        for payer in 0..profile.senders {
            for offset in 0..profile.out_degree {
                oracle_credits[(payer + offset) % profile.credited_accounts] += 1;
            }
        }
        accounts.truncate(profile.senders);
        accounts.shrink_to_fit();
        let validators = Validators::new();
        let assignment = validators.assignment();
        let spans = validators.spans(&assignment);
        let distinct = validators.distinct_spans(&assignment);
        assert_eq!(spans.len(), VALIDATORS);
        let operator_private = Private::new(Scalar::from(OPERATOR_SEED));
        Self {
            profile,
            cache,
            payers: accounts,
            recipients,
            oracle_credits,
            operator: SigningKey::from_seed(OPERATOR_SEED),
            operator_bls: compute_public::<OperatorVariant>(&operator_private),
            operator_private,
            validators,
            spans,
            distinct,
            deposits: DepositBatch::empty(),
            withdrawals: WithdrawalBatch::empty(),
        }
    }

    fn context(&self, step: usize) -> Context {
        let step = u64::try_from(step).unwrap();
        EpochContext::new::<Sha256>(
            Sha256::hash(&[b"clearing-benchmark-deployment"]),
            FIRST_EPOCH.checked_add(step).unwrap(),
            self.operator.public_key(),
            &self.deposits,
            &self.withdrawals,
            self.cache.liability(),
            98_u64.checked_add(step).unwrap(),
            99_u64.checked_add(step).unwrap(),
            CloseLimits::protocol_maximum(),
            self.validators.assignment(),
        )
        .and_then(|epoch| epoch.bind::<Sha256>(&self.cache, &self.deposits, &self.withdrawals))
        .expect("consecutive reference context")
    }

    // The sender fleet owns epoch vectors, roots, signatures, and incremental accumulator
    // partials. No recipient collation, row arithmetic, or prefix construction happens here.
    fn terminals(&self, context: &Context, step: usize) -> Terminals {
        let cumulative_debit = u64::try_from(step)
            .unwrap()
            .checked_add(1)
            .unwrap()
            .checked_mul(u64::try_from(self.profile.out_degree).unwrap())
            .unwrap();
        let items = strategy().map_collect_vec(
            self.payers.iter().enumerate(),
            |(index, (public, private))| {
                let mut entries = (0..self.profile.out_degree)
                    .map(|offset| OutEntry {
                        recipient: self.recipients[(index + offset) % self.recipients.len()]
                            .clone(),
                        cumulative: 1,
                        count: 1,
                    })
                    .collect::<Vec<_>>();
                entries.sort_unstable_by(|left, right| left.recipient.cmp(&right.recipient));
                let vector =
                    OutVector::new(context.payment().epoch(), public.clone(), entries).unwrap();
                let root = vector.root::<Sha256, Digest>().unwrap();

                // Sequence and edge counters are epoch-local; the signed debit is lifetime-wide.
                let body = VectorSendBody::new(
                    context.payment(),
                    public.clone(),
                    0,
                    cumulative_debit,
                    root,
                );
                let ack = VectorAck::sign_by_authorities(body, private, &self.operator);
                let operator_signature = sign_message::<OperatorVariant>(
                    &self.operator_private,
                    VECTOR_ACK_AGGREGATE_NAMESPACE,
                    ack.body().encode().as_ref(),
                );
                Terminal {
                    vector,
                    authorization: SendAuthorization::from_raw_unchecked(
                        ack.body().clone(),
                        ack.payer_signature().clone(),
                    ),
                    operator_signature,
                }
            },
        );
        let partials =
            strategy().map_collect_vec(items.iter(), |terminal| terminal.vector.accumulator());
        Terminals { items, partials }
    }

    fn produce(&mut self, context: &Context, terminals: Terminals) -> Produced {
        let Terminals {
            items,
            mut partials,
        } = terminals;
        let mut transpose = items
            .iter()
            .flat_map(|terminal| {
                terminal
                    .vector
                    .entries()
                    .iter()
                    .map(move |entry| TransposeEntry {
                        recipient: entry.recipient.clone(),
                        payer: terminal.vector.payer().clone(),
                        cumulative: entry.cumulative,
                        count: entry.count,
                    })
            })
            .collect::<Vec<_>>();
        strategy().sort_by(&mut transpose, |left, right| {
            left.recipient
                .cmp(&right.recipient)
                .then_with(|| left.payer.cmp(&right.payer))
        });
        let mut terminals = items.into_iter().peekable();
        let mut leaves = self.cache.leaves().iter().peekable();
        let mut cursor = 0;
        let mut rows = Vec::new();
        let mut vectors = Vec::new();
        let mut signatures = Vec::new();
        let mut prefix = Prefix::default();
        while terminals.peek().is_some() || cursor < transpose.len() {
            let account = match (terminals.peek(), transpose.get(cursor)) {
                (Some(terminal), Some(entry)) => {
                    terminal.vector.payer().min(&entry.recipient).clone()
                }
                (Some(terminal), None) => terminal.vector.payer().clone(),
                (None, Some(entry)) => entry.recipient.clone(),
                (None, None) => unreachable!(),
            };
            while leaves.peek().is_some_and(|leaf| leaf.account < account) {
                leaves.next();
            }
            let predecessor = leaves
                .peek()
                .filter(|leaf| leaf.account == account)
                .expect("all workload accounts exist")
                .state;
            let start = cursor;
            let mut credit = 0_u64;
            let mut receipts = 0_u64;
            while transpose
                .get(cursor)
                .is_some_and(|entry| entry.recipient == account)
            {
                credit = credit.checked_add(transpose[cursor].cumulative).unwrap();
                receipts = receipts.checked_add(transpose[cursor].count).unwrap();
                cursor += 1;
            }
            let terminal = terminals
                .peek()
                .is_some_and(|terminal| terminal.vector.payer() == &account)
                .then(|| terminals.next().unwrap());
            let (vector, outgoing, signature) = match terminal {
                Some(terminal) => (
                    terminal.vector,
                    Some(terminal.authorization),
                    Some(terminal.operator_signature),
                ),
                None => {
                    // The workload's payers are the first A canonical accounts, so any
                    // receive-only row follows all payer rows and their supplied partials.
                    assert!(terminals.peek().is_none());
                    partials.push(LtHash::new());
                    (
                        OutVector::empty(context.payment().epoch(), account.clone()),
                        None,
                        None,
                    )
                }
            };
            let debit = vector.totals().unwrap().0;
            let successor = AccountState {
                balance: predecessor
                    .balance
                    .checked_sub(debit)
                    .expect("fixed sequence remains funded")
                    .checked_add(credit)
                    .unwrap(),
                cumulative_debit: predecessor.cumulative_debit.checked_add(debit).unwrap(),
                cumulative_credit: predecessor.cumulative_credit.checked_add(credit).unwrap(),
                receipt_count: predecessor.receipt_count.checked_add(receipts).unwrap(),
                active: true,
            };
            assert!(
                successor.balance > 0,
                "fixed workload must retain every account"
            );
            prefix = prefix
                .checked_extend(Prefix {
                    debit,
                    credit,
                    out_count: vector.entries().len() as u64,
                    in_count: (cursor - start) as u64,
                    ..Prefix::default()
                })
                .unwrap();
            rows.push(AccountRow {
                account,
                predecessor,
                successor,
                outgoing,
                output: SettlementOutput::None,
                prefix,
            });
            vectors.push(vector);
            signatures.push(signature);
        }
        let prepared = prepare_close_with_strategy::<Sha256, _, _>(
            &self.cache,
            context,
            &self.deposits,
            &self.withdrawals,
            rows,
            vectors,
            &partials,
            &signatures,
            transpose,
            strategy(),
        )
        .expect("reference close prepares");
        drop(partials);
        drop(signatures);
        let dealings = prepared
            .deal(&self.cache, &self.distinct, strategy())
            .expect("reference close deals");
        let mut envelope = BytesMut::new();
        prepared.close().header.write(&mut envelope);
        prepared.close().roots.write(&mut envelope);
        let envelope = envelope.freeze();
        let packets = self
            .spans
            .iter()
            .map(|assigned| Packet {
                envelope: envelope.clone(),
                slices: assigned
                    .iter()
                    .map(|span| dealings.encode_span(span))
                    .collect(),
            })
            .collect();

        // StateCache exposes no incremental successor installation. Its complete leaf vector
        // and tree are rebuilt here, inside prepare-apply's measured operation.
        let close = prepared.close();
        let mut unchanged = close.unchanged.iter().peekable();
        let mut successor = Vec::with_capacity(self.cache.len());
        for row in &close.rows {
            while unchanged
                .peek()
                .is_some_and(|leaf| leaf.account < row.account)
            {
                successor.push(unchanged.next().unwrap().clone());
            }
            if row.successor.active {
                successor.push(StateLeaf {
                    account: row.account.clone(),
                    state: row.successor,
                });
            }
        }
        successor.extend(unchanged.cloned());
        self.cache = Cache::new_with_strategy::<Sha256>(successor, strategy())
            .expect("reference successor cache");
        Produced { prepared, packets }
    }

    fn expected_state(&self, index: usize, rounds: usize) -> AccountState {
        let rounds = u64::try_from(rounds).unwrap();
        let debit = if index < self.profile.senders {
            self.profile.out_degree as u64
        } else {
            0
        };
        let debit = debit.checked_mul(rounds).unwrap();
        let credit = self
            .oracle_credits
            .get(index)
            .copied()
            .unwrap_or(0)
            .checked_mul(rounds)
            .unwrap();
        AccountState {
            balance: OPENING_BALANCE
                .checked_sub(debit)
                .unwrap()
                .checked_add(credit)
                .unwrap(),
            cumulative_debit: debit,
            cumulative_credit: credit,
            receipt_count: credit,
            active: true,
        }
    }

    fn check_close(&self, prepared: &Prepared, rounds: usize) {
        assert_eq!(self.cache.root(), prepared.close().roots.successor);
        for (position, row) in prepared.close().rows.iter().enumerate() {
            let account = if position < self.profile.senders {
                assert_eq!(row.account, self.payers[position].0);
                position
            } else {
                self.recipients.binary_search(&row.account).unwrap()
            };
            assert_eq!(row.predecessor, self.expected_state(account, rounds - 1));
            assert_eq!(row.successor, self.expected_state(account, rounds));
        }
    }

    fn check_final_state(&self, rounds: usize) {
        assert_eq!(self.cache.len(), self.profile.live_accounts);
        let mut hasher = Sha256::default();
        hasher.update(&(self.cache.len() as u64).to_be_bytes());
        for (index, leaf) in self.cache.leaves().iter().enumerate() {
            assert_eq!(leaf.state, self.expected_state(index, rounds));
            hasher.update(leaf.account.as_ref());
            hasher.update(&leaf.state.balance.to_be_bytes());
        }
        println!(
            "{{\"record\":\"oracle\",\"variant\":\"reference\",\"completed_epochs\":{rounds},\"logical_state_sha256\":\"{}\",\"status\":\"passed\"}}",
            hasher.finalize().1
        );
    }
}

fn largest(packets: &[Packet]) -> usize {
    let maximum = packets.iter().map(Packet::size).max().unwrap();
    packets
        .iter()
        .position(|packet| packet.size() == maximum)
        .unwrap()
}

fn predecessor_intervals(
    prepared: &Prepared,
    spans: &[Range<u16>],
    bits: u8,
) -> Vec<Interval<Key>> {
    let close = prepared.close();
    spans
        .iter()
        .map(|span| {
            let mut unchanged = close.unchanged.iter().peekable();
            let mut leaves = Vec::new();
            for row in &close.rows {
                while unchanged
                    .peek()
                    .is_some_and(|leaf| leaf.account < row.account)
                {
                    let leaf = unchanged.next().unwrap();
                    if span.contains(&account_slice(&leaf.account, bits).unwrap()) {
                        leaves.push(leaf.clone());
                    }
                }
                if row.predecessor.active
                    && span.contains(&account_slice(&row.account, bits).unwrap())
                {
                    leaves.push(StateLeaf {
                        account: row.account.clone(),
                        state: row.predecessor,
                    });
                }
            }
            leaves.extend(
                unchanged
                    .filter(|leaf| span.contains(&account_slice(&leaf.account, bits).unwrap()))
                    .cloned(),
            );
            Interval::new(leaves).expect("genesis retained interval")
        })
        .collect()
}

fn decode(
    source: &Source,
    context: &Context,
    packet: &Packet,
    wire: &[Bytes],
    intervals: &[Interval<Key>],
) -> (
    Header<Digest>,
    RootBundle<Digest>,
    Vec<ProofSlice<Key, Digest>>,
) {
    let mut envelope = packet.envelope.clone();
    let header = Header::<Digest>::read(&mut envelope).unwrap();
    let roots = RootBundle::<Digest>::read(&mut envelope).unwrap();
    assert!(envelope.is_empty());
    assert_eq!(wire.len(), intervals.len());
    let slices = wire
        .iter()
        .zip(intervals)
        .map(|(encoded, interval)| {
            decode_dealt_slice_bounded(encoded, *context.limits(), encoded.len())
                .unwrap()
                .hydrate::<Sha256>(interval, context, &source.deposits, &source.withdrawals)
                .unwrap()
        })
        .collect();
    (header, roots, slices)
}

fn seal_decoded(
    source: &Source,
    context: &Context,
    signer: &bls12381::Scheme,
    decoded: (
        Header<Digest>,
        RootBundle<Digest>,
        Vec<ProofSlice<Key, Digest>>,
    ),
    rng: &mut TestRng,
) -> (Vote, SealedDealing<Key, Digest>) {
    let (header, roots, slices) = decoded;
    seal::<Sha256, _, _, PaymentBatchVerifier, _>(
        signer,
        context,
        &source.operator_bls,
        &source.deposits,
        &source.withdrawals,
        &header,
        &roots,
        slices,
        rng,
        strategy(),
    )
    .expect("reference validator seals")
}

/// Runs one operation in one process, with one genesis and a fixed number of raw samples.
/// Prepare and receive modes advance every epoch; `seal-predecoded` repeats epoch seven.
pub fn run(mode: &str, samples: usize, warmup: usize) {
    assert!(samples > 0);
    let steps = samples.checked_add(warmup).unwrap();
    let mut source = Source::new(latency_profile());
    match mode {
        "prepare-apply" => {
            for step in 0..steps {
                let context = source.context(step);
                let terminals = source.terminals(&context, step);
                let start = Instant::now();
                let produced = source.produce(&context, terminals);
                let elapsed = start.elapsed();
                source.check_close(&produced.prepared, step + 1);
                black_box(&produced);
                crate::emit_sample(mode, step, warmup, elapsed);
            }
            source.check_final_state(steps);
        }
        "receive-apply" => {
            let mut selected = None;
            let mut intervals = Vec::new();
            for step in 0..steps {
                let context = source.context(step);
                let terminals = source.terminals(&context, step);

                // This is the external producer fixture. Its full reference cache rebuild is
                // explicit untimed producer work; the receiver keeps its own retained intervals.
                let produced = source.produce(&context, terminals);
                let largest_now = largest(&produced.packets);
                let validator = *selected.get_or_insert(largest_now);
                assert_eq!(
                    produced.packets[validator].size(),
                    produced.packets[largest_now].size(),
                    "the retained validator must remain a maximum-payload validator"
                );
                if step == 0 {
                    intervals = predecessor_intervals(
                        &produced.prepared,
                        &source.spans[validator],
                        context.assignment().slice_bits(),
                    );
                    eprintln!(
                        "reference maximum-payload validator={validator} packet_bytes={}",
                        produced.packets[validator].size()
                    );
                }
                let signer = source.validators.signer(Participant::from_usize(validator));
                let packet = &produced.packets[validator];
                let wire = packet
                    .slices
                    .iter()
                    .map(|slice| slice.encode())
                    .collect::<Vec<_>>();
                let mut rng = TestRng::new(step as u64);
                let start = Instant::now();
                let decoded = decode(&source, &context, packet, &wire, &intervals);
                let (vote, sealed) = seal_decoded(&source, &context, &signer, decoded, &mut rng);
                for (interval, slice) in intervals.iter_mut().zip(sealed.slices()) {
                    interval.advance(slice);
                }
                let elapsed = start.elapsed();
                black_box((&vote, &sealed, &intervals));
                source.check_close(&produced.prepared, step + 1);
                crate::emit_sample(mode, step, warmup, elapsed);
            }
            for interval in intervals {
                for leaf in interval.leaves() {
                    let index = source
                        .cache
                        .leaves()
                        .binary_search_by(|actual| actual.account.cmp(&leaf.account))
                        .unwrap();
                    assert_eq!(source.cache.leaves()[index], *leaf);
                }
            }
            source.check_final_state(steps);
        }
        "receive-phases" => {
            let mut selected = None;
            let mut intervals = Vec::new();
            for step in 0..steps {
                let context = source.context(step);
                let terminals = source.terminals(&context, step);

                // This is the external producer fixture. Its full reference cache rebuild is
                // explicit untimed producer work; the receiver keeps its own retained intervals.
                let produced = source.produce(&context, terminals);
                let largest_now = largest(&produced.packets);
                let validator = *selected.get_or_insert(largest_now);
                assert_eq!(
                    produced.packets[validator].size(),
                    produced.packets[largest_now].size(),
                    "the retained validator must remain a maximum-payload validator"
                );
                if step == 0 {
                    intervals = predecessor_intervals(
                        &produced.prepared,
                        &source.spans[validator],
                        context.assignment().slice_bits(),
                    );
                    eprintln!(
                        "reference maximum-payload validator={validator} packet_bytes={}",
                        produced.packets[validator].size()
                    );
                }
                let signer = source.validators.signer(Participant::from_usize(validator));
                let packet = &produced.packets[validator];
                let wire = packet
                    .slices
                    .iter()
                    .map(|slice| slice.encode())
                    .collect::<Vec<_>>();
                let mut rng = TestRng::new(step as u64);
                assert_eq!(wire.len(), intervals.len());
                let total_start = Instant::now();
                let phase_start = Instant::now();
                let mut envelope = packet.envelope.clone();
                let header = Header::<Digest>::read(&mut envelope).unwrap();
                let roots = RootBundle::<Digest>::read(&mut envelope).unwrap();
                assert!(envelope.is_empty());
                let decoded = wire
                    .iter()
                    .map(|encoded| {
                        decode_dealt_slice_bounded::<Key, Digest>(
                            encoded,
                            *context.limits(),
                            encoded.len(),
                        )
                        .unwrap()
                    })
                    .collect::<Vec<_>>();
                let decode_elapsed = phase_start.elapsed();

                let phase_start = Instant::now();
                let slices = decoded
                    .into_iter()
                    .zip(&intervals)
                    .map(|(decoded, interval)| {
                        decoded
                            .hydrate::<Sha256>(
                                interval,
                                &context,
                                &source.deposits,
                                &source.withdrawals,
                            )
                            .unwrap()
                    })
                    .collect();
                let hydrate_elapsed = phase_start.elapsed();

                let phase_start = Instant::now();
                let (vote, sealed) = seal_decoded(
                    &source,
                    &context,
                    &signer,
                    (header, roots, slices),
                    &mut rng,
                );
                let verify_elapsed = phase_start.elapsed();

                let phase_start = Instant::now();
                for (interval, slice) in intervals.iter_mut().zip(sealed.slices()) {
                    interval.advance(slice);
                }
                let apply_elapsed = phase_start.elapsed();
                let elapsed = total_start.elapsed();
                black_box((&vote, &sealed, &intervals));
                source.check_close(&produced.prepared, step + 1);
                crate::emit_sample(mode, step, warmup, elapsed);
                crate::emit_phase(mode, "decode", step, warmup, decode_elapsed);
                crate::emit_phase(mode, "resident-hydrate", step, warmup, hydrate_elapsed);
                crate::emit_phase(mode, "verify-and-vote", step, warmup, verify_elapsed);
                crate::emit_phase(mode, "apply", step, warmup, apply_elapsed);
            }
            for interval in intervals {
                for leaf in interval.leaves() {
                    let index = source
                        .cache
                        .leaves()
                        .binary_search_by(|actual| actual.account.cmp(&leaf.account))
                        .unwrap();
                    assert_eq!(source.cache.leaves()[index], *leaf);
                }
            }
            source.check_final_state(steps);
        }
        "seal-predecoded" => {
            let context = source.context(0);
            let terminals = source.terminals(&context, 0);
            let produced = source.produce(&context, terminals);
            source.check_close(&produced.prepared, 1);
            let validator = largest(&produced.packets);
            let intervals = predecessor_intervals(
                &produced.prepared,
                &source.spans[validator],
                context.assignment().slice_bits(),
            );
            let packet = &produced.packets[validator];
            let wire = packet
                .slices
                .iter()
                .map(|slice| slice.encode())
                .collect::<Vec<_>>();
            let signer = source.validators.signer(Participant::from_usize(validator));
            for step in 0..steps {
                let decoded = decode(&source, &context, packet, &wire, &intervals);
                let mut rng = TestRng::new(step as u64);
                let start = Instant::now();
                let (vote, sealed) = seal_decoded(&source, &context, &signer, decoded, &mut rng);
                let elapsed = start.elapsed();
                black_box((&vote, &sealed));
                crate::emit_sample(mode, step, warmup, elapsed);
            }
            source.check_final_state(1);
        }
        _ => panic!("unsupported reference latency mode: {mode}"),
    }
}
